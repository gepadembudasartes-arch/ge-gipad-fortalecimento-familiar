import express from 'express';
import path from 'path';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI } from '@google/genai';
import dotenv from 'dotenv';

dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json());

// Initialize Gemini API client on the server side
const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY || '',
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    },
  },
});

// Health check endpoint
app.get('/api/health', (_req, res) => {
  res.json({
    status: 'ok',
    service: 'GEPAD GÊ — Embu das Artes',
    timestamp: new Date().toISOString(),
  });
});

// Chat API endpoint for GÊ Mascot Assistant
app.post('/api/chat', async (req, res) => {
  try {
    const { message, history } = req.body;

    if (!message || typeof message !== 'string') {
      return res.status(400).json({ error: 'Mensagem é obrigatória.' });
    }

    const systemInstruction = `Você é o "GÊ", o mascote amigável, inteligente e empático da plataforma educativa "GÊ — Geração, Educação e Encontro", criada pelo GEPAD (Grupo de Educação e Prevenção às Drogas) da Guarda Civil Municipal (GCM) de Embu das Artes, São Paulo.

MISSÃO DO GÊ:
- Apoiar e orientar jovens, crianças, pais, familiares e educadores na prevenção ao uso de drogas e substâncias.
- Promover a cultura de paz, fortalecimento de vínculos familiares, empatia, respeito e inteligência emocional.
- Oferecer orientação prática para lidar com pressão dos colegas (bullying/cyberbullying), ansiedade escolar, escolhas de vida e diálogo em família.
- Divulgar e orientar sobre os canais de apoio locais de Embu das Artes/SP (GCM 153, Conselho Tutelar, CAPS Infanto-Juvenil e CAPS AD, SAMU 192, CVV 188).

DIRETRIZES DE COMUNICAÇÃO:
1. Tom Acolhedor e Respeitoso: Seja atencioso, positivo, sem julgamentos ou pregadores.
2. Linguagem Clara e Direta: Use português do Brasil com ótima pontuação.
3. Adaptação ao Usuário: Se o usuário demonstrar ser estudante/jovem, seja dinâmico e encorajador. Se for pai/mãe ou educador, dê orientações pedagógicas e familiares práticas.
4. Segurança e Emergência: NUNCA forneça diagnósticos médicos. Se o usuário relatar sofrimento grave, ideação suicida ou emergência, oriente buscar ajuda e forneça os contatos de emergência (CVV 188, SAMU 192, GCM Embu 153).
5. Encerramento Amigável: Finalize suas respostas com uma pergunta atenciosa ou uma palavra de motivação.`;

    // Construct conversation contents for Gemini
    const contents: Array<{ role: string; parts: Array<{ text: string }> }> = [];

    if (Array.isArray(history)) {
      for (const item of history) {
        if (item && item.text) {
          contents.push({
            role: item.role === 'user' ? 'user' : 'model',
            parts: [{ text: item.text }],
          });
        }
      }
    }

    contents.push({
      role: 'user',
      parts: [{ text: message }],
    });

    const response = await ai.models.generateContent({
      model: 'gemini-3.6-flash',
      contents,
      config: {
        systemInstruction,
        temperature: 0.7,
      },
    });

    const reply = response.text || 'Olá! Como posso ajudar você e sua família hoje com orientações do GEPAD?';
    return res.json({ reply });
  } catch (error: any) {
    console.error('Erro no processamento da API do GÊ:', error);
    return res.status(500).json({
      error: 'Erro ao se comunicar com o assistente GÊ. Tente novamente em instantes.',
      details: error?.message || 'Ocorreu um problema no servidor.',
    });
  }
});

async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`[GEPAD GÊ] Servidor ativo em http://0.0.0.0:${PORT}`);
  });
}

startServer();
