export type ActiveTab = 'home' | 'chat' | 'guides' | 'games' | 'community' | 'support' | 'profile';

export type UserRole = 'estudante' | 'pai_mae' | 'educador' | 'comunidade';

export interface UserProfile {
  name: string;
  role: UserRole;
  schoolOrNeighborhood?: string;
  xp: number;
  level: number;
  completedQuizzes: number;
  readGuides: string[];
  badges: string[];
  joinedDate: string;
}

export interface ChatMessage {
  id: string;
  sender: 'user' | 'ge';
  text: string;
  timestamp: string;
}

export interface GuideArticle {
  id: string;
  title: string;
  category: 'jovens' | 'pais' | 'educadores' | 'cidadania';
  summary: string;
  content: string[];
  tips: string[];
  readTime: string;
  iconName: string;
  tags: string[];
}

export interface QuizQuestion {
  id: number;
  statement: string;
  isTrue: boolean; // true = Verdade, false = Mito
  explanation: string;
  category: string;
}

export interface ScenarioNode {
  id: string;
  title: string;
  situation: string;
  character: string;
  choices: {
    text: string;
    nextId: string;
    xpGain: number;
    feedback: string;
  }[];
  isEnding?: boolean;
  endingMessage?: string;
  endingType?: 'positive' | 'neutral' | 'lesson';
}

export interface SupportContact {
  id: string;
  name: string;
  category: 'emergencia' | 'gcm' | 'psicossocial' | 'protecao';
  phone: string;
  address?: string;
  neighborhood?: string;
  hours?: string;
  description: string;
  urgent?: boolean;
}

export interface Pledge {
  id: string;
  authorName: string;
  authorRole: string;
  message: string;
  category: string;
  likes: number;
  date: string;
}

export interface GepadEvent {
  id: string;
  title: string;
  location: string;
  date: string;
  time: string;
  targetAudience: string;
  description: string;
}

export interface Badge {
  id: string;
  title: string;
  description: string;
  icon: string;
  requiredXp: number;
  unlocked: boolean;
}
