import React from 'react';

interface GepadLogoProps {
  className?: string;
  size?: number | string;
  variant?: 'full' | 'emblem' | 'compact';
  glow?: boolean;
}

export const GepadLogo: React.FC<GepadLogoProps> = ({
  className = '',
  size = 64,
  variant = 'full',
  glow = true,
}) => {
  const numericSize = typeof size === 'number' ? size : 64;

  return (
    <div
      className={`inline-flex flex-col items-center justify-center transition-all ${
        glow ? 'drop-shadow-[0_0_15px_rgba(6,182,212,0.4)]' : ''
      } ${className}`}
    >
      <svg
        width={numericSize}
        height={variant === 'full' ? (numericSize * 0.95) : (numericSize * 0.75)}
        viewBox="0 0 500 460"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        className="w-auto h-auto max-w-full"
      >
        <defs>
          {/* Cyber-Gothic Gradient Accents */}
          <linearGradient id="gepadHandGradLeft" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#FF7A00" />
            <stop offset="60%" stopColor="#FFC700" />
            <stop offset="100%" stopColor="#0284C7" />
          </linearGradient>

          <linearGradient id="gepadHandGradRight" x1="100%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%" stopColor="#FF7A00" />
            <stop offset="60%" stopColor="#FFC700" />
            <stop offset="100%" stopColor="#0284C7" />
          </linearGradient>

          <linearGradient id="gepadHeartGrad" x1="0%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%" stopColor="#0284C7" />
            <stop offset="100%" stopColor="#0369A1" />
          </linearGradient>

          <filter id="neonGlowGepad" x1="-20%" y1="-20%" width="140%" height="140%">
            <feGaussianBlur stdDeviation="6" result="blur" />
            <feComposite in="SourceGraphic" in2="blur" operator="over" />
          </filter>
        </defs>

        {/* --- HANDS & HEART STRUCTURE --- */}
        <g id="hands-and-heart">
          {/* Left Protective Hand / Wing */}
          <path
            d="M 120 260 C 90 240 50 190 40 140 C 30 80 80 20 150 20 C 190 20 220 50 240 80 C 230 110 210 150 180 180 C 160 200 135 225 120 260 Z"
            fill="url(#gepadHandGradLeft)"
            stroke="#0284C7"
            strokeWidth="10"
            strokeLinejoin="round"
          />
          {/* Left Hand Fingers */}
          <path
            d="M 65 155 C 80 185 105 210 130 230 M 80 120 C 105 150 130 185 150 210 M 110 80 C 135 110 160 150 175 185"
            stroke="#0284C7"
            strokeWidth="8"
            strokeLinecap="round"
          />

          {/* Right Protective Hand / Wing */}
          <path
            d="M 380 260 C 410 240 450 190 460 140 C 470 80 420 20 350 20 C 310 20 280 50 260 80 C 270 110 290 150 320 180 C 340 200 365 225 380 260 Z"
            fill="url(#gepadHandGradRight)"
            stroke="#0284C7"
            strokeWidth="10"
            strokeLinejoin="round"
          />
          {/* Right Hand Fingers */}
          <path
            d="M 435 155 C 420 185 395 210 370 230 M 420 120 C 395 150 370 185 350 210 M 390 80 C 365 110 340 150 325 185"
            stroke="#0284C7"
            strokeWidth="8"
            strokeLinecap="round"
          />

          {/* Center Blue Heart Container */}
          <path
            d="M 250 260 C 210 210 160 160 160 110 C 160 70 195 50 225 60 C 240 65 248 75 250 82 C 252 75 260 65 275 60 C 305 50 340 70 340 110 C 340 160 290 210 250 260 Z"
            fill="url(#gepadHeartGrad)"
            stroke="#38BDF8"
            strokeWidth="6"
          />

          {/* --- PEOPLE SILHOUETTES INSIDE HEART --- */}
          {/* Back Yellow Person */}
          <circle cx="215" cy="110" r="12" fill="#FFD600" />
          <path d="M 200 145 C 200 128 230 128 230 145 Z" fill="#FFD600" />

          {/* Back Orange Person */}
          <circle cx="285" cy="110" r="12" fill="#FFC700" />
          <path d="M 270 145 C 270 128 300 128 300 145 Z" fill="#FFC700" />

          {/* Top Magenta Person */}
          <circle cx="250" cy="100" r="12" fill="#D946EF" />
          <path d="M 235 135 C 235 118 265 118 265 135 Z" fill="#D946EF" />

          {/* Center Front Purple/Magenta Person */}
          <circle cx="250" cy="140" r="14" fill="#C084FC" />
          <path d="M 230 190 C 230 162 270 162 270 190 Z" fill="#C084FC" />

          {/* Left Pink/Purple Person */}
          <circle cx="220" cy="150" r="13" fill="#EC4899" />
          <path d="M 202 195 C 202 170 238 170 238 195 Z" fill="#EC4899" />

          {/* Right Pink/Purple Person */}
          <circle cx="280" cy="150" r="13" fill="#EC4899" />
          <path d="M 262 195 C 262 170 298 170 298 195 Z" fill="#EC4899" />

          {/* Small Mascot GÊ Silhoette at front center */}
          <rect x="242" y="180" width="16" height="20" rx="4" fill="#38BDF8" />
          <circle cx="250" cy="174" r="7" fill="#38BDF8" />
        </g>

        {/* --- OPEN BOOK AT BASE --- */}
        <g id="open-book">
          {/* Book Pages Base Shading */}
          <path
            d="M 50 285 Q 250 220 450 285 L 440 310 Q 250 260 60 310 Z"
            fill="#94A3B8"
          />
          <path
            d="M 60 300 Q 250 240 440 300 L 420 318 Q 250 270 80 318 Z"
            fill="#CBD5E1"
          />
          {/* Spine & Page Curve Lines */}
          <path
            d="M 50 285 Q 250 230 450 285"
            stroke="#0284C7"
            strokeWidth="8"
            fill="none"
            strokeLinecap="round"
          />
          <path
            d="M 250 250 L 250 280"
            stroke="#0284C7"
            strokeWidth="6"
            strokeLinecap="round"
          />
        </g>

        {/* --- BOLD "GEPAD" TEXT --- */}
        <g id="gepad-text">
          <text
            x="250"
            y="385"
            textAnchor="middle"
            fontFamily="'Impact', 'Arial Black', sans-serif"
            fontSize="78"
            fontWeight="900"
            letterSpacing="6"
            fill="#0284C7"
            stroke="#0284C7"
            strokeWidth="2"
          >
            GEPAD
          </text>
        </g>

        {/* --- ORANGE ACCENT LINE & SUBTITLE --- */}
        {variant === 'full' && (
          <g id="gepad-subtitle">
            {/* Thick Orange Accent Bar */}
            <rect x="20" y="405" width="460" height="10" rx="5" fill="#FF6B00" />

            {/* Subtitle Text */}
            <text
              x="250"
              y="442"
              textAnchor="middle"
              fontFamily="'Trebuchet MS', 'Arial', sans-serif"
              fontSize="24"
              fontWeight="800"
              fill="#0284C7"
              letterSpacing="0.5"
            >
              Grupo de Educação e Prevenção às Drogas
            </text>
          </g>
        )}
      </svg>
    </div>
  );
};
