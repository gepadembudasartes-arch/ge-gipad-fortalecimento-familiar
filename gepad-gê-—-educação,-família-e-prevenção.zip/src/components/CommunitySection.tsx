import React, { useState } from 'react';
import {
  Users,
  Heart,
  PlusCircle,
  Calendar,
  MapPin,
  Clock,
  Sparkles,
  Send,
  MessageSquare,
  CheckCircle2,
  X
} from 'lucide-react';
import { Pledge, GepadEvent, UserRole } from '../types';
import { INITIAL_PLEDGES, GEPAD_EVENTS } from '../data/commitmentsData';
import { GepadLogo } from './GepadLogo';

interface CommunitySectionProps {
  userRole: UserRole;
  userName: string;
  onRewardXp: (amount: number) => void;
}

export const CommunitySection: React.FC<CommunitySectionProps> = ({
  userRole,
  userName,
  onRewardXp,
}) => {
  const [pledges, setPledges] = useState<Pledge[]>(INITIAL_PLEDGES);
  const [activeCategory, setActiveCategory] = useState<string>('todos');
  const [showAddModal, setShowAddModal] = useState(false);

  const [messageInput, setMessageInput] = useState('');
  const [categoryInput, setCategoryInput] = useState('Jovens');

  const handleLike = (id: string) => {
    setPledges((prev) =>
      prev.map((p) => (p.id === id ? { ...p, likes: p.likes + 1 } : p))
    );
  };

  const handleAddPledge = (e: React.FormEvent) => {
    e.preventDefault();
    if (!messageInput.trim()) return;

    const roleMap: Record<UserRole, string> = {
      estudante: 'Estudante em Embu das Artes',
      pai_mae: 'Pai / Mãe',
      educador: 'Educador(a)',
      comunidade: 'Membro da Comunidade',
    };

    const newPledge: Pledge = {
      id: Date.now().toString(),
      authorName: userName,
      authorRole: roleMap[userRole],
      message: messageInput.trim(),
      category: categoryInput,
      likes: 1,
      date: 'Hoje',
    };

    setPledges([newPledge, ...pledges]);
    setMessageInput('');
    setShowAddModal(false);
    onRewardXp(15);
  };

  const filteredPledges = pledges.filter((p) => {
    if (activeCategory === 'todos') return true;
    return p.category.toLowerCase() === activeCategory.toLowerCase();
  });

  return (
    <div className="space-y-8 animate-fadeIn pb-12">
      {/* Top Banner */}
      <div className="bg-[#0C0D16] p-6 sm:p-8 rounded-3xl border border-purple-900/60 shadow-lg flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <GepadLogo size={52} variant="compact" glow={true} />
          <div>
            <span className="text-[10px] font-cyber font-bold uppercase tracking-widest text-teal-300 bg-teal-950 border border-teal-800 px-3 py-1 rounded">
              Mural do Encontro & Integração Neon
            </span>
            <h2 className="text-2xl sm:text-3xl font-cyber font-bold text-slate-100 mt-1">
              Compromissos com a Vida
            </h2>
            <p className="text-xs text-slate-400 font-sans mt-0.5">
              Mural da comunidade, mensagens inspiradoras e agenda de encontros do GEPAD em Embu das Artes.
            </p>
          </div>
        </div>

        <button
          onClick={() => setShowAddModal(true)}
          className="bg-gradient-to-r from-cyan-500 to-purple-600 hover:from-cyan-400 hover:to-purple-500 text-slate-950 font-cyber font-black px-5 py-3 rounded-xl text-xs sm:text-sm flex items-center gap-2 shadow-[0_0_15px_rgba(6,182,212,0.4)] transition-all cursor-pointer shrink-0"
        >
          <PlusCircle className="w-4 h-4 text-slate-950" />
          <span>DEIXAR MEU COMPROMISSO</span>
        </button>
      </div>

      {/* Main Grid */}
      <div className="grid lg:grid-cols-12 gap-8">
        {/* Left Column: Pledges List */}
        <div className="lg:col-span-8 space-y-6">
          {/* Category Filter */}
          <div className="flex gap-2 overflow-x-auto pb-1 no-scrollbar">
            {['todos', 'Jovens', 'Família', 'Educação', 'GEPAD'].map((cat) => (
              <button
                key={cat}
                onClick={() => setActiveCategory(cat)}
                className={`px-3.5 py-1.5 rounded-xl text-xs font-cyber font-bold capitalize transition-all cursor-pointer ${
                  activeCategory === cat
                    ? 'bg-gradient-to-r from-purple-900 to-cyan-950 text-cyan-300 border border-cyan-500/50'
                    : 'bg-[#0C0D16] text-slate-400 hover:text-slate-200 border border-purple-900/40'
                }`}
              >
                {cat === 'todos' ? 'Todos os Registros' : cat}
              </button>
            ))}
          </div>

          {/* Cards Stream */}
          <div className="space-y-4">
            {filteredPledges.map((pledge) => (
              <div
                key={pledge.id}
                className="bg-[#0C0D16] p-5 sm:p-6 rounded-2xl border border-purple-900/50 shadow-lg space-y-3 hover:border-cyan-500/50 transition-all"
              >
                <div className="flex items-center justify-between gap-2">
                  <div className="flex items-center gap-2.5">
                    <div className="w-9 h-9 rounded-xl bg-purple-900 border border-cyan-500/50 text-cyan-300 font-cyber font-bold flex items-center justify-center text-xs shadow-md">
                      {pledge.authorName.charAt(0).toUpperCase()}
                    </div>
                    <div>
                      <h3 className="font-cyber font-bold text-slate-100 text-sm leading-tight">
                        {pledge.authorName}
                      </h3>
                      <p className="text-[10px] text-slate-400 font-mono">{pledge.authorRole}</p>
                    </div>
                  </div>

                  <span className="text-[9px] font-cyber font-bold uppercase tracking-widest bg-purple-950 text-purple-300 border border-purple-800 px-2.5 py-1 rounded">
                    {pledge.category}
                  </span>
                </div>

                <p className="text-xs sm:text-sm text-slate-200 leading-relaxed font-sans italic bg-slate-950/80 p-3.5 rounded-xl border border-purple-900/40">
                  "{pledge.message}"
                </p>

                <div className="flex items-center justify-between text-xs text-slate-500 font-mono pt-1">
                  <span>{pledge.date}</span>

                  <button
                    onClick={() => handleLike(pledge.id)}
                    className="flex items-center gap-1.5 text-rose-400 font-cyber font-bold hover:bg-rose-950/40 px-3 py-1 rounded-lg transition-colors cursor-pointer border border-rose-900/40"
                  >
                    <Heart className="w-4 h-4 fill-rose-500 text-rose-400" />
                    <span>{pledge.likes} Apoios</span>
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Right Column: Events Agenda */}
        <div className="lg:col-span-4 space-y-6">
          <div className="bg-[#0C0D16] p-6 rounded-3xl border border-purple-900/60 shadow-lg space-y-5">
            <div className="flex items-center gap-2 border-b border-purple-900/40 pb-3">
              <Calendar className="w-5 h-5 text-cyan-400" />
              <h3 className="font-cyber font-bold text-slate-100 text-base">
                Agenda GEPAD Embu
              </h3>
            </div>

            <div className="space-y-4">
              {GEPAD_EVENTS.map((evt) => (
                <div
                  key={evt.id}
                  className="bg-slate-950 p-4 rounded-2xl border border-purple-900/40 space-y-2 hover:border-purple-600 transition-colors"
                >
                  <span className="text-[9px] font-cyber font-bold uppercase text-cyan-300 bg-cyan-950 border border-cyan-800 px-2 py-0.5 rounded inline-block">
                    {evt.targetAudience}
                  </span>

                  <h4 className="font-cyber font-bold text-slate-100 text-xs sm:text-sm leading-snug">
                    {evt.title}
                  </h4>

                  <div className="space-y-1 text-[11px] text-slate-400 font-mono pt-1">
                    <div className="flex items-center gap-1.5">
                      <Calendar className="w-3.5 h-3.5 text-purple-400 shrink-0" />
                      <span>{evt.date} às {evt.time}</span>
                    </div>
                    <div className="flex items-center gap-1.5">
                      <MapPin className="w-3.5 h-3.5 text-purple-400 shrink-0" />
                      <span className="line-clamp-1">{evt.location}</span>
                    </div>
                  </div>

                  <p className="text-[11px] text-slate-400 pt-1 leading-relaxed font-sans">
                    {evt.description}
                  </p>
                </div>
              ))}
            </div>

            <div className="p-4 rounded-2xl bg-amber-950/40 border border-amber-500/40 text-xs text-amber-200 space-y-1">
              <p className="font-cyber font-bold flex items-center gap-1.5">
                <Sparkles className="w-4 h-4 text-amber-400" />
                Agendar Palestra na sua Escola?
              </p>
              <p className="text-[11px] font-sans">
                Gestores podem agendar palestras do GEPAD ligando para a GCM Embu das Artes: <strong>(11) 4785-3696</strong>.
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Modal: Leave New Pledge */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-[#0D0E18] w-full max-w-lg rounded-3xl shadow-2xl p-6 sm:p-8 space-y-6 animate-scaleUp relative border border-purple-700/60">
            <button
              onClick={() => setShowAddModal(false)}
              className="absolute right-4 top-4 p-2 text-slate-400 hover:text-cyan-300 rounded-full cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>

            <div>
              <h3 className="text-xl font-cyber font-bold text-slate-100">
                Registrar Compromisso com a Vida
              </h3>
              <p className="text-xs text-slate-400 mt-1 font-sans">
                Sua mensagem inspirará jovens e famílias no Mural do Encontro de Embu das Artes.
              </p>
            </div>

            <form onSubmit={handleAddPledge} className="space-y-4 font-sans">
              <div>
                <label className="text-xs font-cyber font-bold text-slate-300 block mb-1">
                  Categoria da Mensagem
                </label>
                <select
                  value={categoryInput}
                  onChange={(e) => setCategoryInput(e.target.value)}
                  className="w-full bg-slate-950 border border-purple-800 rounded-xl p-2.5 text-xs font-cyber text-slate-200"
                >
                  <option value="Jovens">Jovens (Autonomia e Sonhos)</option>
                  <option value="Família">Família (Diálogo e Afeto)</option>
                  <option value="Educação">Educação (Escola Acolhedora)</option>
                  <option value="Comunidade">Comunidade e Cidadania</option>
                </select>
              </div>

              <div>
                <label className="text-xs font-cyber font-bold text-slate-300 block mb-1">
                  Seu Compromisso
                </label>
                <textarea
                  rows={4}
                  value={messageInput}
                  onChange={(e) => setMessageInput(e.target.value)}
                  placeholder="Ex: Comprometo-me a acolher e ouvir mais quem precisa..."
                  className="w-full bg-slate-950 border border-purple-800 rounded-xl p-3 text-xs sm:text-sm text-slate-100 placeholder-slate-500 focus:outline-none focus:border-cyan-400"
                  required
                />
              </div>

              <div className="pt-2 flex justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2.5 rounded-xl text-xs font-cyber font-bold text-slate-400 hover:bg-slate-900 cursor-pointer"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="bg-gradient-to-r from-cyan-500 to-purple-600 hover:from-cyan-400 hover:to-purple-500 text-slate-950 font-cyber font-black px-5 py-2.5 rounded-xl text-xs flex items-center gap-2 shadow-[0_0_15px_rgba(6,182,212,0.4)] cursor-pointer"
                >
                  <Send className="w-4 h-4 text-slate-950" />
                  <span>PUBLICAR (+15 XP)</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
