import React from 'react';
import geRobotImg from '../assets/images/ge_robot_avatar_1786551830169.jpg';

interface GLogoProps {
  className?: string;
  size?: number;
  showTitle?: boolean;
}

export const GLogo: React.FC<GLogoProps> = ({ className = '', size = 48, showTitle = false }) => {
  return (
    <div className={`inline-flex items-center gap-3 ${className}`}>
      <div className="relative group shrink-0">
        <div className="absolute -inset-1 rounded-2xl bg-gradient-to-r from-purple-600 via-cyan-500 to-amber-400 opacity-60 group-hover:opacity-100 blur-xs transition duration-300"></div>
        <div
          style={{ width: `${size}px`, height: `${size}px` }}
          className="relative rounded-2xl overflow-hidden shadow-[0_0_20px_rgba(139,92,246,0.4)] transition-transform group-hover:scale-105 border border-cyan-400/80 bg-slate-950 flex items-center justify-center animate-robot-float"
        >
          <img
            src={geRobotImg}
            alt="Robô GÊ - Assistente GEPAD"
            className="w-full h-full object-cover object-center"
            referrerPolicy="no-referrer"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-transparent via-cyan-500/5 to-purple-900/10 pointer-events-none" />
        </div>
      </div>

      {showTitle && (
        <div className="flex flex-col justify-center">
          <div className="flex items-center gap-1.5">
            <span className="font-cyber font-black text-xl tracking-wider text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-purple-400">
              GÊ
            </span>
            <span className="text-[9px] font-cyber font-extrabold px-2 py-0.5 rounded bg-purple-950 border border-purple-700/60 text-purple-300">
              GEPAD GCM
            </span>
          </div>
          <span className="text-xs text-slate-400 font-mono tracking-wide">
            Geração • Educação • Encontro
          </span>
        </div>
      )}
    </div>
  );
};
