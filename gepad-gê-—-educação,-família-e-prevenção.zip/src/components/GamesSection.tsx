import React, { useState, useEffect } from 'react';
import {
  Gamepad2,
  HelpCircle,
  Sparkles,
  CheckCircle2,
  XCircle,
  RotateCcw,
  Trophy,
  ArrowRight,
  Compass,
  Heart,
  Brain,
  Award,
  Zap,
  Flame
} from 'lucide-react';
import { QUIZ_QUESTIONS } from '../data/quizData';
import { SCENARIO_TREE } from '../data/scenarioData';
import { GepadLogo } from './GepadLogo';

interface GamesSectionProps {
  onRewardXp: (amount: number) => void;
  onIncrementQuizCount: () => void;
}

export const GamesSection: React.FC<GamesSectionProps> = ({
  onRewardXp,
  onIncrementQuizCount,
}) => {
  const [activeGame, setActiveGame] = useState<'quiz' | 'scenario' | 'memory'>('quiz');

  // QUIZ STATE
  const [quizIdx, setQuizIdx] = useState(0);
  const [quizScore, setQuizScore] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<boolean | null>(null);
  const [quizCompleted, setQuizCompleted] = useState(false);

  // SCENARIO GAME STATE
  const [currentNodeId, setCurrentNodeId] = useState('start');
  const [scenarioXpTotal, setScenarioXpTotal] = useState(0);
  const [choiceFeedback, setChoiceFeedback] = useState<string | null>(null);

  // MEMORY GAME STATE
  const memoryHabits = [
    { id: 1, title: 'Praticar Esporte', icon: '⚽' },
    { id: 2, title: 'Diálogo Familiar', icon: '💬' },
    { id: 3, title: 'Leitura e Estudo', icon: '📚' },
    { id: 4, title: 'Arte e Música', icon: '🎨' },
    { id: 5, title: 'Boa Noite de Sono', icon: '🌙' },
    { id: 6, title: 'Amizades Reais', icon: '🤝' },
    { id: 7, title: 'Respeito e Afeto', icon: '❤️' },
    { id: 8, title: 'Contato com Natureza', icon: '🌿' },
  ];

  const [cards, setCards] = useState<Array<{ id: number; habitId: number; title: string; icon: string; isFlipped: boolean; isMatched: boolean }>>([]);
  const [flippedCards, setFlippedCards] = useState<number[]>([]);
  const [memoryMoves, setMemoryMoves] = useState(0);
  const [memoryWon, setMemoryWon] = useState(false);

  const initMemoryGame = () => {
    const duplicated = [...memoryHabits, ...memoryHabits].map((item, idx) => ({
      id: idx,
      habitId: item.id,
      title: item.title,
      icon: item.icon,
      isFlipped: false,
      isMatched: false,
    }));
    const shuffled = duplicated.sort(() => Math.random() - 0.5);
    setCards(shuffled);
    setFlippedCards([]);
    setMemoryMoves(0);
    setMemoryWon(false);
  };

  useEffect(() => {
    initMemoryGame();
  }, []);

  const handleCardClick = (index: number) => {
    if (flippedCards.length === 2 || cards[index].isFlipped || cards[index].isMatched) {
      return;
    }

    const newCards = [...cards];
    newCards[index].isFlipped = true;
    setCards(newCards);

    const newFlipped = [...flippedCards, index];
    setFlippedCards(newFlipped);

    if (newFlipped.length === 2) {
      setMemoryMoves((m) => m + 1);
      const [firstIdx, secondIdx] = newFlipped;

      if (newCards[firstIdx].habitId === newCards[secondIdx].habitId) {
        newCards[firstIdx].isMatched = true;
        newCards[secondIdx].isMatched = true;
        setCards(newCards);
        setFlippedCards([]);

        if (newCards.every((c) => c.isMatched)) {
          setMemoryWon(true);
          onRewardXp(30);
        }
      } else {
        setTimeout(() => {
          newCards[firstIdx].isFlipped = false;
          newCards[secondIdx].isFlipped = false;
          setCards(newCards);
          setFlippedCards([]);
        }, 1000);
      }
    }
  };

  const currentQuizQuestion = QUIZ_QUESTIONS[quizIdx];

  const handleQuizAnswer = (answer: boolean) => {
    if (selectedAnswer !== null) return;
    setSelectedAnswer(answer);

    const isCorrect = answer === currentQuizQuestion.isTrue;
    if (isCorrect) {
      setQuizScore((prev) => prev + 1);
    }
  };

  const handleNextQuiz = () => {
    if (quizIdx < QUIZ_QUESTIONS.length - 1) {
      setQuizIdx((prev) => prev + 1);
      setSelectedAnswer(null);
    } else {
      setQuizCompleted(true);
      onRewardXp(quizScore * 10 + 20);
      onIncrementQuizCount();
    }
  };

  const restartQuiz = () => {
    setQuizIdx(0);
    setQuizScore(0);
    setSelectedAnswer(null);
    setQuizCompleted(false);
  };

  const currentNode = SCENARIO_TREE[currentNodeId];

  const handleScenarioChoice = (nextId: string, xpGain: number, feedback: string) => {
    setScenarioXpTotal((prev) => prev + xpGain);
    setChoiceFeedback(feedback);

    setTimeout(() => {
      setCurrentNodeId(nextId);
      setChoiceFeedback(null);
      if (SCENARIO_TREE[nextId]?.isEnding) {
        onRewardXp(scenarioXpTotal + xpGain);
      }
    }, 1200);
  };

  const restartScenario = () => {
    setCurrentNodeId('start');
    setScenarioXpTotal(0);
    setChoiceFeedback(null);
  };

  return (
    <div className="space-y-6 animate-fadeIn pb-12">
      {/* Top Selector Banner */}
      <div className="bg-[#0C0D16] p-6 rounded-3xl border border-purple-900/60 shadow-lg flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <GepadLogo size={52} variant="compact" glow={true} />
          <div>
            <span className="text-[10px] font-cyber font-bold uppercase tracking-widest text-amber-400 bg-amber-950/80 border border-amber-800 px-3 py-1 rounded">
              DESAFIOS & ARENA DE APRENDIZADO
            </span>
            <h2 className="text-2xl font-cyber font-bold text-slate-100 mt-1">
              Desafios Interativos com o GÊ
            </h2>
            <p className="text-xs text-slate-400 font-sans mt-0.5">
              Quizzes, árvores de escolha e teste de memória para acumular XP e consolidar a prevenção.
            </p>
          </div>
        </div>

        {/* Sub-tab Navigation */}
        <div className="flex bg-slate-950 p-1.5 rounded-2xl border border-purple-900/60 gap-1 w-full md:w-auto">
          <button
            onClick={() => setActiveGame('quiz')}
            className={`flex-1 md:flex-none px-4 py-2 rounded-xl text-xs font-cyber font-bold transition-all cursor-pointer ${
              activeGame === 'quiz'
                ? 'bg-gradient-to-r from-purple-900 to-cyan-950 text-cyan-300 border border-cyan-500/50 shadow-[0_0_12px_rgba(6,182,212,0.3)]'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Mitos x Verdades
          </button>
          <button
            onClick={() => setActiveGame('scenario')}
            className={`flex-1 md:flex-none px-4 py-2 rounded-xl text-xs font-cyber font-bold transition-all cursor-pointer ${
              activeGame === 'scenario'
                ? 'bg-gradient-to-r from-purple-900 to-cyan-950 text-cyan-300 border border-cyan-500/50 shadow-[0_0_12px_rgba(6,182,212,0.3)]'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Escolhas
          </button>
          <button
            onClick={() => setActiveGame('memory')}
            className={`flex-1 md:flex-none px-4 py-2 rounded-xl text-xs font-cyber font-bold transition-all cursor-pointer ${
              activeGame === 'memory'
                ? 'bg-gradient-to-r from-purple-900 to-cyan-950 text-cyan-300 border border-cyan-500/50 shadow-[0_0_12px_rgba(6,182,212,0.3)]'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Memória
          </button>
        </div>
      </div>

      {/* GAME 1: QUIZ MITOS X VERDADES */}
      {activeGame === 'quiz' && (
        <div className="bg-[#0C0D16] rounded-3xl border border-purple-900/60 p-6 sm:p-8 shadow-2xl max-w-3xl mx-auto space-y-6">
          {!quizCompleted ? (
            <div>
              {/* Question Header */}
              <div className="flex items-center justify-between pb-4 border-b border-purple-900/40 mb-6">
                <span className="text-[10px] font-cyber font-bold text-cyan-300 uppercase tracking-widest bg-cyan-950 border border-cyan-800 px-3 py-1 rounded">
                  PERGUNTA {quizIdx + 1} DE {QUIZ_QUESTIONS.length}
                </span>
                <span className="text-xs font-cyber font-bold text-amber-400">
                  Pontuação: {quizScore}
                </span>
              </div>

              {/* Question Statement Card */}
              <div className="bg-slate-950 p-6 rounded-2xl border border-purple-800/50 mb-6">
                <span className="text-[9px] font-cyber font-bold uppercase text-purple-400 block mb-1">
                  Categoria: {currentQuizQuestion.category}
                </span>
                <h3 className="text-base sm:text-lg font-cyber font-bold text-slate-100 leading-snug">
                  "{currentQuizQuestion.statement}"
                </h3>
              </div>

              {/* True / False Buttons */}
              <div className="grid grid-cols-2 gap-4 mb-6">
                <button
                  onClick={() => handleQuizAnswer(true)}
                  disabled={selectedAnswer !== null}
                  className={`p-4 sm:p-5 rounded-2xl font-cyber font-bold text-sm sm:text-base border transition-all cursor-pointer flex flex-col items-center justify-center gap-2 ${
                    selectedAnswer === true
                      ? currentQuizQuestion.isTrue
                        ? 'bg-emerald-950 text-emerald-300 border-emerald-500 shadow-[0_0_20px_rgba(16,185,129,0.3)]'
                        : 'bg-rose-950 text-rose-300 border-rose-500 shadow-[0_0_20px_rgba(244,63,94,0.3)]'
                      : 'bg-emerald-950/40 hover:bg-emerald-900/50 text-emerald-300 border-emerald-800/60'
                  }`}
                >
                  <CheckCircle2 className="w-6 h-6 text-emerald-400" />
                  <span>VERDADE</span>
                </button>

                <button
                  onClick={() => handleQuizAnswer(false)}
                  disabled={selectedAnswer !== null}
                  className={`p-4 sm:p-5 rounded-2xl font-cyber font-bold text-sm sm:text-base border transition-all cursor-pointer flex flex-col items-center justify-center gap-2 ${
                    selectedAnswer === false
                      ? !currentQuizQuestion.isTrue
                        ? 'bg-emerald-950 text-emerald-300 border-emerald-500 shadow-[0_0_20px_rgba(16,185,129,0.3)]'
                        : 'bg-rose-950 text-rose-300 border-rose-500 shadow-[0_0_20px_rgba(244,63,94,0.3)]'
                      : 'bg-rose-950/40 hover:bg-rose-900/50 text-rose-300 border-rose-800/60'
                  }`}
                >
                  <XCircle className="w-6 h-6 text-rose-400" />
                  <span>MITO</span>
                </button>
              </div>

              {/* Feedback Explanation */}
              {selectedAnswer !== null && (
                <div
                  className={`p-5 rounded-2xl border text-xs sm:text-sm space-y-2 animate-fadeIn mb-6 ${
                    selectedAnswer === currentQuizQuestion.isTrue
                      ? 'bg-emerald-950/60 border-emerald-600/60 text-emerald-200'
                      : 'bg-amber-950/60 border-amber-600/60 text-amber-200'
                  }`}
                >
                  <div className="font-cyber font-bold flex items-center gap-2 text-sm">
                    {selectedAnswer === currentQuizQuestion.isTrue ? (
                      <>
                        <CheckCircle2 className="w-5 h-5 text-emerald-400" />
                        <span>RESPOSTA CORRETA!</span>
                      </>
                    ) : (
                      <>
                        <XCircle className="w-5 h-5 text-amber-400" />
                        <span>NA VERDADE É {currentQuizQuestion.isTrue ? 'VERDADE' : 'MITO'}!</span>
                      </>
                    )}
                  </div>
                  <p className="leading-relaxed font-sans">
                    {currentQuizQuestion.explanation}
                  </p>
                </div>
              )}

              {/* Next Button */}
              {selectedAnswer !== null && (
                <button
                  onClick={handleNextQuiz}
                  className="w-full bg-gradient-to-r from-cyan-500 to-purple-600 hover:from-cyan-400 hover:to-purple-500 text-slate-950 font-cyber font-black py-3.5 rounded-xl text-sm flex items-center justify-center gap-2.5 shadow-[0_0_20px_rgba(6,182,212,0.4)] transition-all cursor-pointer"
                >
                  <span>{quizIdx < QUIZ_QUESTIONS.length - 1 ? 'PRÓXIMA PERGUNTA' : 'VER RESULTADO FINAL'}</span>
                  <ArrowRight className="w-4 h-4 text-slate-950" />
                </button>
              )}
            </div>
          ) : (
            /* Quiz Results Screen */
            <div className="text-center space-y-6 py-6 animate-fadeIn">
              <div className="w-20 h-20 bg-amber-950/80 border border-amber-500 text-amber-400 rounded-2xl flex items-center justify-center mx-auto shadow-[0_0_25px_rgba(245,158,11,0.4)]">
                <Trophy className="w-10 h-10" />
              </div>

              <div>
                <h3 className="text-2xl font-cyber font-bold text-slate-100">
                  DESAFIO CONCLUÍDO!
                </h3>
                <p className="text-sm text-slate-300 mt-1 font-sans">
                  Você acertou <strong className="text-cyan-300 font-cyber font-bold">{quizScore}</strong> de {QUIZ_QUESTIONS.length} perguntas e acumulou <strong className="text-amber-400 font-cyber font-bold">+{quizScore * 10 + 20} XP</strong>!
                </p>
              </div>

              <div className="bg-slate-950 p-4 rounded-2xl border border-purple-800/50 text-xs text-slate-300 max-w-md mx-auto font-sans">
                {quizScore >= 6 ? (
                  <p>🌟 Excelente! Seu nível de conscientização sobre prevenção e escolhas saudáveis está alto!</p>
                ) : (
                  <p>💪 Ótimo esforço! Consulte o Codex Educativo do GEPAD para aprimorar ainda mais seus conhecimentos!</p>
                )}
              </div>

              <button
                onClick={restartQuiz}
                className="bg-purple-900 hover:bg-purple-800 text-cyan-300 border border-cyan-500/40 font-cyber font-bold px-6 py-3 rounded-xl text-sm inline-flex items-center gap-2 shadow-md transition-all cursor-pointer"
              >
                <RotateCcw className="w-4 h-4" />
                <span>JOGAR NOVAMENTE</span>
              </button>
            </div>
          )}
        </div>
      )}

      {/* GAME 2: CAMINHO DAS ESCOLHAS */}
      {activeGame === 'scenario' && currentNode && (
        <div className="bg-[#0C0D16] rounded-3xl border border-purple-900/60 p-6 sm:p-8 shadow-2xl max-w-3xl mx-auto space-y-6">
          <div className="flex items-center justify-between pb-4 border-b border-purple-900/40">
            <div className="flex items-center gap-2">
              <Compass className="w-5 h-5 text-cyan-400" />
              <span className="text-xs font-cyber font-bold text-slate-200">
                Personagem: {currentNode.character}
              </span>
            </div>
            <span className="text-xs font-cyber font-bold text-amber-400 bg-amber-950 border border-amber-700 px-2.5 py-1 rounded">
              XP Acumulado: +{scenarioXpTotal}
            </span>
          </div>

          <div className="space-y-3">
            <h3 className="text-xl font-cyber font-bold text-cyan-300">
              {currentNode.title}
            </h3>
            <p className="text-sm text-slate-200 leading-relaxed bg-slate-950 p-5 rounded-2xl border border-purple-800/50 font-sans">
              {currentNode.situation}
            </p>
          </div>

          {choiceFeedback && (
            <div className="p-4 bg-purple-950/80 border border-cyan-500/50 text-cyan-300 text-xs font-cyber font-bold rounded-xl animate-fadeIn flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-amber-400" />
              <span>{choiceFeedback}</span>
            </div>
          )}

          {!currentNode.isEnding ? (
            <div className="space-y-3 pt-2">
              <p className="text-[10px] font-cyber font-bold text-purple-400 uppercase tracking-widest">
                Qual deve ser a decisão?
              </p>
              {currentNode.choices.map((choice, idx) => (
                <button
                  key={idx}
                  onClick={() =>
                    handleScenarioChoice(choice.nextId, choice.xpGain, choice.feedback)
                  }
                  disabled={choiceFeedback !== null}
                  className="w-full text-left p-4 rounded-2xl border border-purple-900/60 hover:border-cyan-400 bg-slate-950 hover:bg-purple-950/60 transition-all text-xs sm:text-sm font-sans font-medium text-slate-200 flex items-center justify-between gap-3 group cursor-pointer"
                >
                  <span>{choice.text}</span>
                  <ArrowRight className="w-4 h-4 text-purple-400 group-hover:text-cyan-300 group-hover:translate-x-1 transition-transform shrink-0" />
                </button>
              ))}
            </div>
          ) : (
            <div className="text-center space-y-6 pt-4 border-t border-purple-900/40 animate-fadeIn">
              <div className="p-6 rounded-2xl bg-emerald-950/80 border border-emerald-500 text-emerald-200 space-y-2 font-sans text-sm">
                <p className="font-bold">
                  {currentNode.endingMessage}
                </p>
              </div>

              <button
                onClick={restartScenario}
                className="bg-purple-900 hover:bg-purple-800 text-cyan-300 border border-cyan-500/40 font-cyber font-bold px-6 py-3 rounded-xl text-sm inline-flex items-center gap-2 shadow-md transition-all cursor-pointer"
              >
                <RotateCcw className="w-4 h-4" />
                <span>JOGAR OUTRO CENÁRIO</span>
              </button>
            </div>
          )}
        </div>
      )}

      {/* GAME 3: MEMORY GAME */}
      {activeGame === 'memory' && (
        <div className="bg-[#0C0D16] rounded-3xl border border-purple-900/60 p-6 sm:p-8 shadow-2xl max-w-3xl mx-auto space-y-6">
          <div className="flex items-center justify-between pb-4 border-b border-purple-900/40">
            <div>
              <h3 className="text-lg font-cyber font-bold text-slate-100">
                Memória dos Hábitos Saudáveis
              </h3>
              <p className="text-xs text-slate-400 font-sans">Encontre os pares de hábitos de proteção.</p>
            </div>
            <div className="flex items-center gap-3">
              <span className="text-xs font-cyber font-bold text-slate-300">Jogadas: {memoryMoves}</span>
              <button
                onClick={initMemoryGame}
                className="p-2 text-cyan-300 hover:bg-purple-900/50 bg-slate-950 border border-purple-800/60 rounded-xl text-xs font-cyber font-bold flex items-center gap-1 cursor-pointer"
                title="Reiniciar"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>Reiniciar</span>
              </button>
            </div>
          </div>

          <div className="grid grid-cols-4 gap-3">
            {cards.map((card, index) => {
              const isOpen = card.isFlipped || card.isMatched;

              return (
                <button
                  key={index}
                  onClick={() => handleCardClick(index)}
                  className={`h-24 sm:h-28 rounded-2xl border font-cyber font-bold flex flex-col items-center justify-center p-2 text-center transition-all cursor-pointer select-none ${
                    isOpen
                      ? 'bg-purple-950/80 border-cyan-400 text-slate-100 shadow-[0_0_15px_rgba(6,182,212,0.3)] scale-95'
                      : 'bg-gradient-to-br from-slate-950 to-purple-950 border-purple-800 text-cyan-300 hover:border-cyan-400'
                  }`}
                >
                  {isOpen ? (
                    <>
                      <span className="text-2xl sm:text-3xl mb-1">{card.icon}</span>
                      <span className="text-[10px] sm:text-xs font-sans font-bold leading-tight line-clamp-2">
                        {card.title}
                      </span>
                    </>
                  ) : (
                    <span className="text-lg font-black text-purple-400">GEPAD</span>
                  )}
                </button>
              );
            })}
          </div>

          {memoryWon && (
            <div className="bg-emerald-950/80 border border-emerald-500 p-6 rounded-2xl text-center space-y-3 animate-fadeIn">
              <div className="w-12 h-12 bg-emerald-900 border border-emerald-400 text-emerald-300 rounded-xl flex items-center justify-center mx-auto font-black text-2xl">
                🏆
              </div>
              <h4 className="text-lg font-cyber font-bold text-emerald-300">
                PARABÉNS! PARES ENCONTRADOS!
              </h4>
              <p className="text-xs text-emerald-200 font-sans">
                Você completou em <strong>{memoryMoves} jogadas</strong> e acumulou <strong className="font-bold">+30 XP</strong>!
              </p>
              <button
                onClick={initMemoryGame}
                className="bg-emerald-800 hover:bg-emerald-700 text-white font-cyber font-bold px-5 py-2.5 rounded-xl text-xs inline-flex items-center gap-2 shadow-sm cursor-pointer"
              >
                <RotateCcw className="w-4 h-4" />
                <span>JOGAR DE NOVO</span>
              </button>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
