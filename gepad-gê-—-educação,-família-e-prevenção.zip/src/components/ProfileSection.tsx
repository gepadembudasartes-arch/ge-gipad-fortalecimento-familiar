import React, { useRef } from 'react';
import {
  User,
  Award,
  Sparkles,
  CheckCircle2,
  Lock,
  Printer,
  ShieldCheck,
  BookOpen,
  Gamepad2,
  Bot,
  Heart,
  Zap
} from 'lucide-react';
import { UserRole, Badge } from '../types';
import { GLogo } from './GLogo';
import { GepadLogo } from './GepadLogo';

interface ProfileSectionProps {
  userName: string;
  setUserName: (name: string) => void;
  userRole: UserRole;
  setUserRole: (role: UserRole) => void;
  schoolOrNeighborhood: string;
  setSchoolOrNeighborhood: (val: string) => void;
  xp: number;
  level: number;
  completedQuizzes: number;
  readGuidesCount: number;
}

export const ProfileSection: React.FC<ProfileSectionProps> = ({
  userName,
  setUserName,
  userRole,
  setUserRole,
  schoolOrNeighborhood,
  setSchoolOrNeighborhood,
  xp,
  level,
  completedQuizzes,
  readGuidesCount,
}) => {
  const certificateRef = useRef<HTMLDivElement>(null);

  const roleLabels: Record<UserRole, string> = {
    estudante: 'Estudante',
    pai_mae: 'Pai / Mãe / Responsável',
    educador: 'Educador(a) / Professor(a)',
    comunidade: 'Membro da Comunidade',
  };

  const badgesList: Badge[] = [
    {
      id: 'pioneiro',
      title: 'Pioneiro da Prevenção',
      description: 'Conectou-se ao Codex do GEPAD GCM Embu das Artes.',
      icon: '🌱',
      requiredXp: 0,
      unlocked: true,
    },
    {
      id: 'dialogo',
      title: 'Mestre do Diálogo',
      description: 'Interagiu com o assistente inteligente GÊ.',
      icon: '💬',
      requiredXp: 10,
      unlocked: xp >= 10,
    },
    {
      id: 'sabio',
      title: 'Sábio das Escolhas',
      description: 'Completou os desafios do Quiz Mitos x Verdades.',
      icon: '🧠',
      requiredXp: 30,
      unlocked: completedQuizzes > 0 || xp >= 30,
    },
    {
      id: 'guardiao',
      title: 'Guardião da Família',
      description: 'Estudou os guias educativos de prevenção.',
      icon: '🛡️',
      requiredXp: 50,
      unlocked: readGuidesCount >= 2 || xp >= 50,
    },
    {
      id: 'embaixador',
      title: 'Embaixador do GEPAD',
      description: 'Alcançou o Nível 3 de engajamento e sabedoria.',
      icon: '👑',
      requiredXp: 100,
      unlocked: level >= 3 || xp >= 100,
    },
  ];

  const handlePrintCertificate = () => {
    window.print();
  };

  return (
    <div className="space-y-8 animate-fadeIn pb-12">
      {/* Top Banner */}
      <div className="bg-[#0C0D16] text-slate-100 p-6 sm:p-8 rounded-3xl border border-purple-900/60 shadow-lg flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
        <div className="flex items-center gap-4">
          <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-purple-800 via-purple-950 to-cyan-600 text-cyan-200 font-cyber font-black text-2xl flex items-center justify-center shadow-[0_0_20px_rgba(139,92,246,0.4)] border border-cyan-400">
            {userName.charAt(0).toUpperCase()}
          </div>
          <div>
            <h2 className="text-2xl font-cyber font-bold text-slate-100">{userName}</h2>
            <p className="text-xs text-cyan-400 font-mono">
              {roleLabels[userRole]} {schoolOrNeighborhood ? `• ${schoolOrNeighborhood}` : ''}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-3 bg-slate-950 p-3.5 rounded-2xl border border-purple-800/60 shadow-md">
          <div className="text-right font-cyber">
            <span className="text-[9px] uppercase font-bold text-purple-400 block tracking-widest">STATUS DA JORNADA</span>
            <span className="text-lg font-black text-amber-400">NÍVEL {level} ({xp} XP)</span>
          </div>
          <Award className="w-8 h-8 text-amber-400 shrink-0" />
        </div>
      </div>

      {/* Edit Profile Form & Stats */}
      <div className="grid md:grid-cols-12 gap-6">
        {/* Profile Form */}
        <div className="md:col-span-6 bg-[#0C0D16] p-6 rounded-3xl border border-purple-900/60 shadow-lg space-y-4">
          <h3 className="font-cyber font-bold text-slate-100 text-base flex items-center gap-2">
            <User className="w-4 h-4 text-cyan-400" />
            Dados de Identificação
          </h3>

          <div className="space-y-3 font-sans">
            <div>
              <label className="text-xs font-cyber font-bold text-slate-300 block mb-1">Seu Nome ou Apelido</label>
              <input
                type="text"
                value={userName}
                onChange={(e) => setUserName(e.target.value)}
                className="w-full bg-slate-950 border border-purple-800 rounded-xl p-2.5 text-xs text-slate-100 focus:border-cyan-400 focus:outline-none font-sans"
              />
            </div>

            <div>
              <label className="text-xs font-cyber font-bold text-slate-300 block mb-1">Perfil no Aplicativo</label>
              <select
                value={userRole}
                onChange={(e) => setUserRole(e.target.value as UserRole)}
                className="w-full bg-slate-950 border border-purple-800 rounded-xl p-2.5 text-xs font-cyber text-slate-200"
              >
                <option value="estudante">Estudante</option>
                <option value="pai_mae">Pai / Mãe / Responsável</option>
                <option value="educador">Educador(a) / Professor(a)</option>
                <option value="comunidade">Membro da Comunidade</option>
              </select>
            </div>

            <div>
              <label className="text-xs font-cyber font-bold text-slate-300 block mb-1">Escola ou Bairro em Embu das Artes</label>
              <input
                type="text"
                value={schoolOrNeighborhood}
                onChange={(e) => setSchoolOrNeighborhood(e.target.value)}
                placeholder="Ex: E.M. Valdelice Prass / Centro"
                className="w-full bg-slate-950 border border-purple-800 rounded-xl p-2.5 text-xs text-slate-100 placeholder-slate-500 focus:border-cyan-400 focus:outline-none font-sans"
              />
            </div>
          </div>
        </div>

        {/* Stats Counter */}
        <div className="md:col-span-6 grid grid-cols-2 gap-4">
          <div className="bg-[#0C0D16] p-5 rounded-3xl border border-purple-900/60 shadow-lg flex flex-col justify-between">
            <div className="w-10 h-10 rounded-xl bg-purple-950 border border-purple-800 text-cyan-400 flex items-center justify-center mb-2">
              <Gamepad2 className="w-5 h-5" />
            </div>
            <div>
              <span className="text-2xl font-cyber font-black text-slate-100">{completedQuizzes}</span>
              <p className="text-xs text-slate-400 font-sans">Quizzes Concluídos</p>
            </div>
          </div>

          <div className="bg-[#0C0D16] p-5 rounded-3xl border border-purple-900/60 shadow-lg flex flex-col justify-between">
            <div className="w-10 h-10 rounded-xl bg-purple-950 border border-purple-800 text-purple-300 flex items-center justify-center mb-2">
              <BookOpen className="w-5 h-5" />
            </div>
            <div>
              <span className="text-2xl font-cyber font-black text-slate-100">{readGuidesCount}</span>
              <p className="text-xs text-slate-400 font-sans">Guias Acessados</p>
            </div>
          </div>

          <div className="bg-[#0C0D16] p-5 rounded-3xl border border-purple-900/60 shadow-lg flex flex-col justify-between col-span-2">
            <div className="w-10 h-10 rounded-xl bg-amber-950 border border-amber-800 text-amber-400 flex items-center justify-center mb-2">
              <Award className="w-5 h-5" />
            </div>
            <div>
              <span className="text-2xl font-cyber font-black text-slate-100">
                {badgesList.filter((b) => b.unlocked).length} / {badgesList.length}
              </span>
              <p className="text-xs text-slate-400 font-sans">Conquistas Desbloqueadas</p>
            </div>
          </div>
        </div>
      </div>

      {/* Badges Collection */}
      <section className="bg-[#0C0D16] p-6 sm:p-8 rounded-3xl border border-purple-900/60 shadow-lg space-y-4">
        <h3 className="font-cyber font-bold text-slate-100 text-lg flex items-center gap-2">
          <Sparkles className="w-5 h-5 text-amber-400" />
          Conquistas no Codex GEPAD
        </h3>

        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {badgesList.map((badge) => (
            <div
              key={badge.id}
              className={`p-4 rounded-2xl border transition-all flex items-start gap-3.5 ${
                badge.unlocked
                  ? 'bg-purple-950/40 border-cyan-500/50 text-slate-100 shadow-[0_0_12px_rgba(6,182,212,0.15)]'
                  : 'bg-slate-950/60 border-purple-900/40 text-slate-500 opacity-60'
              }`}
            >
              <div className="text-2xl p-2 bg-slate-950 rounded-xl border border-purple-800 shrink-0">
                {badge.icon}
              </div>
              <div className="space-y-1 font-sans">
                <div className="flex items-center gap-1.5">
                  <h4 className="font-cyber font-bold text-xs sm:text-sm text-slate-100">{badge.title}</h4>
                  {badge.unlocked ? (
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                  ) : (
                    <Lock className="w-3.5 h-3.5 text-slate-500 shrink-0" />
                  )}
                </div>
                <p className="text-[11px] text-slate-400 leading-relaxed">{badge.description}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Official Printable Certificate with Official GEPAD Logo */}
      <section className="bg-[#0C0D16] p-6 sm:p-8 rounded-3xl border border-purple-900/60 shadow-lg space-y-6">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b border-purple-900/40 pb-4">
          <div>
            <h3 className="text-xl font-cyber font-bold text-slate-100 flex items-center gap-2">
              <ShieldCheck className="w-5 h-5 text-cyan-400" />
              Certificado Oficial Amigo do GEPAD
            </h3>
            <p className="text-xs text-slate-400 font-sans mt-0.5">
              Certificado de engajamento no Programa GÊ da Guarda Civil Municipal de Embu das Artes.
            </p>
          </div>

          <button
            onClick={handlePrintCertificate}
            className="bg-gradient-to-r from-cyan-500 to-purple-600 hover:from-cyan-400 hover:to-purple-500 text-slate-950 font-cyber font-black px-5 py-2.5 rounded-xl text-xs flex items-center gap-2 shadow-[0_0_15px_rgba(6,182,212,0.4)] transition-all cursor-pointer shrink-0"
          >
            <Printer className="w-4 h-4 text-slate-950" />
            <span>IMPRIMIR / GERAR PDF</span>
          </button>
        </div>

        {/* Printable Certificate Frame */}
        <div
          ref={certificateRef}
          className="bg-slate-950 border-4 border-cyan-500/70 p-8 sm:p-12 rounded-2xl text-center space-y-6 shadow-[0_0_30px_rgba(6,182,212,0.2)] relative overflow-hidden print:m-0 print:shadow-none print:bg-white print:text-black print:border-slate-800"
        >
          {/* Header Logos */}
          <div className="flex justify-center items-center gap-6">
            <GepadLogo size={80} variant="full" glow={true} />
            <GLogo size={60} />
          </div>

          <div className="space-y-1">
            <span className="text-[10px] font-cyber font-bold uppercase tracking-widest text-cyan-300 bg-cyan-950 border border-cyan-800 px-3 py-1 rounded">
              CERTIFICADO OFICIAL DE RECONHECIMENTO E PREVENÇÃO
            </span>
            <h4 className="text-2xl sm:text-3xl font-cyber font-bold text-slate-100 pt-2 tracking-wide">
              GUARDA CIVIL MUNICIPAL DE EMBU DAS ARTES
            </h4>
            <p className="text-xs font-cyber font-bold text-purple-300 uppercase tracking-widest">
              PROGRAMA GEPAD — GERAÇÃO, EDUCAÇÃO E ENCONTRO
            </p>
          </div>

          <div className="space-y-2 py-4">
            <p className="text-xs sm:text-sm text-slate-300 font-sans">
              Certificamos que
            </p>
            <h5 className="text-2xl sm:text-3xl font-cyber font-black text-cyan-300 underline decoration-purple-500 decoration-4">
              {userName}
            </h5>
            <p className="text-xs sm:text-sm text-slate-300 max-w-xl mx-auto leading-relaxed pt-2 font-sans">
              participou com êxito das diretrizes de prevenção, educação e promoção da saúde e cidadania promovidas pela Guarda Civil Municipal de Embu das Artes.
            </p>
          </div>

          {/* Certificate Footer Signatures */}
          <div className="pt-6 border-t border-purple-900/50 grid grid-cols-2 gap-6 text-center text-xs font-cyber text-slate-300">
            <div>
              <div className="w-32 h-0.5 bg-cyan-500 mx-auto mb-1"></div>
              <span>Equipe Pedagógica GEPAD</span>
              <p className="text-[10px] font-mono text-slate-400">GCM Embu das Artes • SP</p>
            </div>
            <div>
              <div className="w-32 h-0.5 bg-purple-500 mx-auto mb-1"></div>
              <span>Comissão de Educação</span>
              <p className="text-[10px] font-mono text-slate-400">Plataforma GÊ Cyber</p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};
