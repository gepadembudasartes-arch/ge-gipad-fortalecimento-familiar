import React from 'react';
import geRobotImg from '../assets/images/ge_robot_avatar_1786551830169.jpg';

interface GERobotAvatarProps {
  size?: 'xs' | 'sm' | 'md' | 'lg' | 'xl' | '2xl' | 'hero';
  animated?: boolean;
  showStatus?: boolean;
  glow?: boolean;
  speaking?: boolean;
  className?: string;
}

export const GERobotAvatar: React.FC<GERobotAvatarProps> = ({
  size = 'md',
  animated = true,
  showStatus = true,
  glow = true,
  speaking = false,
  className = '',
}) => {
  // Size mappings in tailwind classes
  const sizeClasses = {
    xs: 'w-6 h-6',
    sm: 'w-8 h-8',
    md: 'w-11 h-11',
    lg: 'w-16 h-16',
    xl: 'w-24 h-24',
    '2xl': 'w-32 h-32',
    hero: 'w-40 h-40 sm:w-48 sm:h-48',
  };

  const statusSizeClasses = {
    xs: 'w-1.5 h-1.5 right-0 bottom-0',
    sm: 'w-2 h-2 right-0 bottom-0',
    md: 'w-3 h-3 right-0.5 bottom-0.5',
    lg: 'w-4 h-4 right-1 bottom-1',
    xl: 'w-5 h-5 right-1.5 bottom-1.5',
    '2xl': 'w-6 h-6 right-2 bottom-2',
    hero: 'w-7 h-7 right-3 bottom-3',
  };

  return (
    <div
      className={`relative inline-block shrink-0 ${
        animated ? 'transition-all duration-300' : ''
      } ${className}`}
    >
      {/* Outer Glow Halo */}
      {glow && (
        <div
          className={`absolute -inset-1 rounded-2xl bg-gradient-to-r from-cyan-500 via-purple-600 to-amber-400 opacity-70 blur-sm ${
            animated ? (speaking ? 'animate-pulse scale-105' : 'animate-tilt') : ''
          }`}
        />
      )}

      {/* Robot Frame Container with Hover Floating Gestures */}
      <div
        className={`relative rounded-2xl overflow-hidden bg-slate-950 border border-cyan-400/80 shadow-[0_0_15px_rgba(6,182,212,0.4)] flex items-center justify-center ${
          sizeClasses[size]
        } ${
          animated
            ? 'hover:scale-105 hover:-translate-y-1 transition-transform duration-300'
            : ''
        }`}
      >
        {/* Robot Face Image */}
        <img
          src={geRobotImg}
          alt="Rosto do Robô GÊ - Assistente GEPAD"
          className={`w-full h-full object-cover object-center ${
            speaking ? 'animate-bounce-subtle' : ''
          }`}
          referrerPolicy="no-referrer"
        />

        {/* Subtle Cyber Grid Overlay Scanline Effect */}
        <div className="absolute inset-0 bg-gradient-to-b from-transparent via-cyan-500/5 to-purple-900/10 pointer-events-none" />

        {/* Gentle Eye Light Glow overlay for extra animation */}
        {animated && (
          <div className="absolute top-[28%] left-[28%] w-[44%] h-[25%] bg-cyan-400/10 rounded-full blur-[2px] animate-pulse pointer-events-none" />
        )}
      </div>

      {/* Online Status Indicator Dot */}
      {showStatus && (
        <span className={`absolute z-10 flex ${statusSizeClasses[size]}`}>
          <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75" />
          <span className="relative inline-flex rounded-full h-full w-full bg-emerald-500 border-2 border-slate-950 shadow-sm" />
        </span>
      )}
    </div>
  );
};
