import React from 'react';
import {
  Bot,
  Gamepad2,
  BookOpen,
  PhoneCall,
  Sparkles,
  ArrowRight,
  ShieldCheck,
  Heart,
  Users,
  Compass,
  Award,
  Calendar,
  CheckCircle2,
  Flame,
  Zap
} from 'lucide-react';
import { ActiveTab, UserRole } from '../types';
import { GLogo } from './GLogo';
import { GepadLogo } from './GepadLogo';
import { GERobotAvatar } from './GERobotAvatar';

interface HomeSectionProps {
  setActiveTab: (tab: ActiveTab) => void;
  userRole: UserRole;
  userName: string;
  xp: number;
}

export const HomeSection: React.FC<HomeSectionProps> = ({
  setActiveTab,
  userRole,
  userName,
  xp
}) => {
  const getGreeting = () => {
    if (userRole === 'estudante') return `Saudações, ${userName}! Conecte-se ao Codex do GEPAD.`;
    if (userRole === 'pai_mae') return `Bem-vindo(a), ${userName}! Fortalecendo famílias na era digital.`;
    if (userRole === 'educador') return `Saudações, Prof. ${userName}! Guardião(ã) do conhecimento.`;
    return `Seja bem-vindo(a), ${userName}!`;
  };

  return (
    <div className="space-y-8 animate-fadeIn pb-12">
      {/* Gothic Cyber Hero Welcome Card */}
      <section className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-[#0B0C16] via-[#121424] to-[#0A101D] text-slate-100 p-6 sm:p-8 md:p-10 border border-purple-900/50 shadow-[0_10px_40px_rgba(0,0,0,0.8)] neon-border-glow">
        {/* Ambient Neon Background Effects */}
        <div className="absolute -right-16 -top-16 w-80 h-80 rounded-full bg-purple-600/10 blur-3xl pointer-events-none"></div>
        <div className="absolute right-1/3 -bottom-20 w-96 h-96 rounded-full bg-cyan-500/10 blur-3xl pointer-events-none"></div>

        <div className="relative z-10 grid md:grid-cols-12 gap-8 items-center">
          <div className="md:col-span-8 space-y-5">
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-xl bg-purple-950/80 border border-purple-700/60 text-cyan-300 text-xs font-cyber font-bold tracking-wide">
              <Sparkles className="w-4 h-4 text-cyan-400 animate-pulse" />
              <span>PLATAFORMA GÓTICO-FUTURISTA GEPAD • GCM EMBU DAS ARTES</span>
            </div>

            <h2 className="text-2xl sm:text-3xl md:text-4xl font-cyber font-black tracking-wider leading-tight text-transparent bg-clip-text bg-gradient-to-r from-cyan-300 via-slate-100 to-purple-300">
              {getGreeting()}
            </h2>

            <p className="text-slate-300 text-sm sm:text-base leading-relaxed max-w-2xl font-sans">
              Eu sou o <strong className="font-cyber text-cyan-300">GÊ</strong>, seu assistente cibernético e guardião de caminhos. 
              Aqui no programa <strong className="font-cyber text-purple-300">Geração, Educação e Encontro</strong> do GEPAD, 
              unimos tecnologia, prevenção e apoio humano para escolhas conscientes e protegidas.
            </p>

            <div className="pt-3 flex flex-wrap gap-4">
              <button
                onClick={() => setActiveTab('chat')}
                className="bg-gradient-to-r from-cyan-500 via-blue-600 to-purple-600 hover:from-cyan-400 hover:to-purple-500 text-slate-950 font-cyber font-black px-6 py-3.5 rounded-xl text-sm flex items-center gap-2.5 shadow-[0_0_20px_rgba(6,182,212,0.4)] transition-all active:scale-95 cursor-pointer border border-cyan-300/40"
              >
                <Bot className="w-5 h-5 text-slate-950" />
                <span>CONVERSAR COM A IA GÊ</span>
                <ArrowRight className="w-4 h-4 text-slate-950" />
              </button>

              <button
                onClick={() => setActiveTab('games')}
                className="bg-slate-900/90 hover:bg-purple-950 text-purple-200 font-cyber font-bold px-5 py-3.5 rounded-xl text-sm border border-purple-700/60 transition-all cursor-pointer flex items-center gap-2 shadow-[0_0_15px_rgba(139,92,246,0.2)]"
              >
                <Gamepad2 className="w-5 h-5 text-cyan-400" />
                <span>DESAFIOS & QUIZ MITOS X VERDADES</span>
              </button>
            </div>
          </div>

          {/* GEPAD Official Emblem + Animated Robot Mascot Showcase */}
          <div className="md:col-span-4 flex flex-col sm:flex-row md:flex-col items-center justify-center gap-4">
            {/* Robot Mascot Card */}
            <div
              onClick={() => setActiveTab('chat')}
              className="p-5 rounded-3xl bg-slate-950/80 backdrop-blur-xl border border-cyan-500/60 shadow-[0_0_30px_rgba(6,182,212,0.3)] flex flex-col items-center cursor-pointer hover:border-cyan-400 hover:scale-105 transition-all group w-full max-w-xs"
            >
              <GERobotAvatar size="hero" animated={true} showStatus={true} glow={true} />
              <div className="mt-3 flex items-center gap-1.5 bg-gradient-to-r from-purple-900 via-indigo-950 to-cyan-950 border border-cyan-500/50 text-cyan-300 text-[10px] font-cyber font-extrabold px-3 py-1 rounded-lg uppercase tracking-widest shadow-md group-hover:scale-105 transition-transform">
                <Sparkles className="w-3 h-3 text-cyan-400 animate-pulse" />
                <span>ROSTO OFICIAL DO GÊ</span>
              </div>
            </div>

            {/* GEPAD Logo Badge */}
            <div className="p-4 rounded-2xl bg-slate-950/60 border border-purple-800/50 flex items-center gap-3 w-full max-w-xs justify-center">
              <GepadLogo size={40} variant="compact" glow={true} />
              <div className="text-left font-cyber">
                <span className="text-[10px] font-bold text-cyan-300 block">SÍMBOLO GEPAD</span>
                <span className="text-[9px] text-slate-400 font-mono">GCM EMBU DAS ARTES</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Cyberpunk Shortcuts Grid */}
      <section className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div
          onClick={() => setActiveTab('chat')}
          className="bg-[#0C0D16] p-5 rounded-2xl border border-purple-900/40 hover:border-cyan-500/60 shadow-lg transition-all cursor-pointer group hover:-translate-y-1 relative overflow-hidden"
        >
          <div className="w-12 h-12 rounded-xl bg-purple-950 text-cyan-400 flex items-center justify-center mb-3 group-hover:bg-cyan-500 group-hover:text-slate-950 transition-colors border border-purple-800/50">
            <Bot className="w-6 h-6" />
          </div>
          <h3 className="font-cyber font-bold text-slate-100 text-base mb-1 flex items-center gap-2">
            Assistente IA GÊ
            <span className="text-[9px] font-cyber font-black bg-cyan-400/20 text-cyan-300 border border-cyan-400/40 px-1.5 py-0.5 rounded">NEON IA</span>
          </h3>
          <p className="text-xs text-slate-400">Tire dúvidas sobre prevenção e escolhas em um terminal seguro.</p>
        </div>

        <div
          onClick={() => setActiveTab('games')}
          className="bg-[#0C0D16] p-5 rounded-2xl border border-purple-900/40 hover:border-amber-500/60 shadow-lg transition-all cursor-pointer group hover:-translate-y-1 relative overflow-hidden"
        >
          <div className="w-12 h-12 rounded-xl bg-amber-950/60 text-amber-400 flex items-center justify-center mb-3 group-hover:bg-amber-500 group-hover:text-slate-950 transition-colors border border-amber-800/50">
            <Gamepad2 className="w-6 h-6" />
          </div>
          <h3 className="font-cyber font-bold text-slate-100 text-base mb-1">Caminho das Escolhas</h3>
          <p className="text-xs text-slate-400">Navegue por cenários interativos de decisão e resiliência.</p>
        </div>

        <div
          onClick={() => setActiveTab('guides')}
          className="bg-[#0C0D16] p-5 rounded-2xl border border-purple-900/40 hover:border-purple-500/60 shadow-lg transition-all cursor-pointer group hover:-translate-y-1 relative overflow-hidden"
        >
          <div className="w-12 h-12 rounded-xl bg-purple-950 text-purple-300 flex items-center justify-center mb-3 group-hover:bg-purple-600 group-hover:text-slate-950 transition-colors border border-purple-800/50">
            <BookOpen className="w-6 h-6" />
          </div>
          <h3 className="font-cyber font-bold text-slate-100 text-base mb-1">Codex Educativo</h3>
          <p className="text-xs text-slate-400">Artigos práticos para Jovens, Famílias, Educadores e Cidadania.</p>
        </div>

        <div
          onClick={() => setActiveTab('support')}
          className="bg-[#0C0D16] p-5 rounded-2xl border border-purple-900/40 hover:border-rose-500/60 shadow-lg transition-all cursor-pointer group hover:-translate-y-1 relative overflow-hidden"
        >
          <div className="w-12 h-12 rounded-xl bg-rose-950/60 text-rose-400 flex items-center justify-center mb-3 group-hover:bg-rose-600 group-hover:text-slate-950 transition-colors border border-rose-800/50">
            <PhoneCall className="w-6 h-6" />
          </div>
          <h3 className="font-cyber font-bold text-slate-100 text-base mb-1">Rede 24h & Apoio</h3>
          <p className="text-xs text-slate-400">Contatos diretos da GCM Embu (153), CAPS, Conselho e CVV 188.</p>
        </div>
      </section>

      {/* Official GEPAD Identity & Mission Section */}
      <section className="bg-[#0C0D16] p-6 sm:p-8 rounded-3xl border border-purple-900/50 shadow-xl space-y-6">
        <div className="flex flex-col md:flex-row items-center justify-between gap-6 pb-6 border-b border-purple-900/30">
          <div className="flex items-center gap-4">
            <GepadLogo size={70} variant="compact" glow={true} />
            <div>
              <span className="text-[10px] font-cyber font-bold text-cyan-400 bg-cyan-950 border border-cyan-800 px-2.5 py-0.5 rounded uppercase tracking-widest">
                Identidade Oficial
              </span>
              <h3 className="text-xl sm:text-2xl font-cyber font-bold text-slate-100 mt-1">
                GEPAD — Grupo de Educação e Prevenção às Drogas
              </h3>
              <p className="text-xs text-slate-400 font-mono">
                Guarda Civil Municipal de Embu das Artes • Estado de São Paulo
              </p>
            </div>
          </div>
        </div>

        {/* The 3 Pillars of GEPAD GÊ in Gothic Cyber style */}
        <div className="grid md:grid-cols-3 gap-6">
          <div className="bg-slate-950/80 p-6 rounded-2xl border border-purple-900/40 hover:border-cyan-500/50 transition-colors space-y-3">
            <div className="w-10 h-10 rounded-xl bg-purple-900 text-cyan-300 font-cyber font-black text-xl flex items-center justify-center border border-cyan-500/40 shadow-[0_0_10px_rgba(6,182,212,0.3)]">
              G
            </div>
            <h4 className="font-cyber font-bold text-cyan-300 text-lg">Geração</h4>
            <p className="text-xs text-slate-300 leading-relaxed">
              Incentivo à autonomia, ao pensamento crítico e à autoconfiança. Fortalecemos a juventude de Embu das Artes para tomadas de decisão conscientes.
            </p>
          </div>

          <div className="bg-slate-950/80 p-6 rounded-2xl border border-purple-900/40 hover:border-purple-500/50 transition-colors space-y-3">
            <div className="w-10 h-10 rounded-xl bg-purple-900 text-purple-300 font-cyber font-black text-xl flex items-center justify-center border border-purple-500/40 shadow-[0_0_10px_rgba(168,85,247,0.3)]">
              E
            </div>
            <h4 className="font-cyber font-bold text-purple-300 text-lg">Educação</h4>
            <p className="text-xs text-slate-300 leading-relaxed">
              Informação baseada em evidências e prevenção primária. Atuação contínua em salas de aula e ambiente comunitário com linguagem direta e humanizada.
            </p>
          </div>

          <div className="bg-slate-950/80 p-6 rounded-2xl border border-purple-900/40 hover:border-amber-500/50 transition-colors space-y-3">
            <div className="w-10 h-10 rounded-xl bg-amber-950 text-amber-300 font-cyber font-black text-xl flex items-center justify-center border border-amber-500/40 shadow-[0_0_10px_rgba(245,158,11,0.3)]">
              E
            </div>
            <h4 className="font-cyber font-bold text-amber-300 text-lg">Encontro</h4>
            <p className="text-xs text-slate-300 leading-relaxed">
              União e laços familiares. Integração sólida entre a Guarda Civil Municipal, escolas, lares e a rede de proteção à vida do município.
            </p>
          </div>
        </div>
      </section>

      {/* Cyberpunk Quote of the Day */}
      <section className="bg-gradient-to-r from-purple-950/60 via-slate-950 to-cyan-950/60 border border-purple-800/50 p-6 rounded-2xl flex flex-col sm:flex-row items-center gap-5 shadow-[0_0_20px_rgba(139,92,246,0.15)]">
        <div className="w-14 h-14 rounded-2xl bg-cyan-500/20 border border-cyan-400/50 text-cyan-300 flex items-center justify-center shrink-0 shadow-[0_0_15px_rgba(6,182,212,0.3)] font-cyber text-2xl">
          🔮
        </div>
        <div className="flex-1 text-center sm:text-left">
          <div className="flex items-center justify-center sm:justify-start gap-2 text-xs font-cyber font-bold text-cyan-400 uppercase tracking-widest mb-1">
            <span>PENSAMENTO DO CODEX GÊ</span>
          </div>
          <p className="text-sm font-sans font-medium text-slate-200 italic">
            "A verdadeira força está em escolher o caminho que constrói o seu futuro com lucidez, resiliência e respeito à vida!"
          </p>
        </div>
        <button
          onClick={() => setActiveTab('community')}
          className="shrink-0 text-xs font-cyber font-bold bg-purple-900/80 hover:bg-purple-800 text-cyan-300 border border-cyan-500/40 px-4 py-2.5 rounded-xl transition-all shadow-[0_0_10px_rgba(6,182,212,0.2)] cursor-pointer"
        >
          REGISTRAR SEU COMPROMISSO
        </button>
      </section>
    </div>
  );
};
