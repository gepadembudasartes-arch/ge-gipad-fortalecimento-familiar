import React, { useState } from 'react';
import {
  BookOpen,
  Search,
  CheckCircle2,
  Bookmark,
  BookmarkCheck,
  ShieldCheck,
  HeartHandshake,
  AlertCircle,
  GraduationCap,
  Building2,
  HelpCircle,
  Clock,
  ArrowRight,
  X,
  Sparkles,
  Award,
  Zap
} from 'lucide-react';
import { GuideArticle, UserRole } from '../types';
import { GUIDES_DATA } from '../data/guidesData';
import { GepadLogo } from './GepadLogo';

interface GuidesSectionProps {
  userRole: UserRole;
  readGuides: string[];
  onMarkAsRead: (guideId: string) => void;
}

export const GuidesSection: React.FC<GuidesSectionProps> = ({
  userRole,
  readGuides,
  onMarkAsRead,
}) => {
  const [activeCategory, setActiveCategory] = useState<string>('todos');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedArticle, setSelectedArticle] = useState<GuideArticle | null>(null);
  const [bookmarks, setBookmarks] = useState<string[]>([]);

  const toggleBookmark = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setBookmarks((prev) =>
      prev.includes(id) ? prev.filter((b) => b !== id) : [...prev, id]
    );
  };

  const filteredArticles = GUIDES_DATA.filter((article) => {
    const matchesCategory =
      activeCategory === 'todos' || article.category === activeCategory;
    const matchesSearch =
      article.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      article.summary.toLowerCase().includes(searchQuery.toLowerCase()) ||
      article.tags.some((t) => t.toLowerCase().includes(searchQuery.toLowerCase()));

    return matchesCategory && matchesSearch;
  });

  const categoryLabels: Record<string, string> = {
    todos: 'Todos os Registros',
    jovens: 'Para Jovens',
    pais: 'Para Pais e Responsáveis',
    educadores: 'Para Educadores',
    cidadania: 'Cidadania e GEPAD',
  };

  const getIcon = (name: string) => {
    switch (name) {
      case 'ShieldCheck':
        return <ShieldCheck className="w-5 h-5 text-cyan-400" />;
      case 'HeartHandshake':
        return <HeartHandshake className="w-5 h-5 text-rose-400" />;
      case 'AlertCircle':
        return <AlertCircle className="w-5 h-5 text-amber-400" />;
      case 'GraduationCap':
        return <GraduationCap className="w-5 h-5 text-purple-400" />;
      case 'Building2':
        return <Building2 className="w-5 h-5 text-emerald-400" />;
      default:
        return <HelpCircle className="w-5 h-5 text-indigo-400" />;
    }
  };

  return (
    <div className="space-y-6 animate-fadeIn pb-12">
      {/* Top Banner */}
      <div className="bg-[#0C0D16] p-6 rounded-3xl border border-purple-900/60 shadow-lg flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <GepadLogo size={52} variant="compact" glow={true} />
          <div>
            <span className="text-[10px] font-cyber font-bold uppercase tracking-widest text-cyan-300 bg-cyan-950 border border-cyan-800 px-3 py-1 rounded">
              Codex & Conhecimento GEPAD
            </span>
            <h2 className="text-2xl font-cyber font-bold text-slate-100 mt-1">
              Guias Informativos de Prevenção
            </h2>
            <p className="text-xs text-slate-400 font-sans mt-0.5">
              Acervo científico e prático sobre escolhas, família, saúde e cidadania em Embu das Artes.
            </p>
          </div>
        </div>

        {/* Search Input */}
        <div className="relative w-full md:w-80">
          <Search className="w-4 h-4 text-purple-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Buscar guias no Codex..."
            className="w-full bg-slate-950 border border-purple-800/70 rounded-xl pl-10 pr-4 py-2.5 text-xs text-slate-100 placeholder-slate-500 focus:outline-none focus:border-cyan-400 font-sans"
          />
        </div>
      </div>

      {/* Category Pills */}
      <div className="flex gap-2 overflow-x-auto pb-1 no-scrollbar">
        {Object.entries(categoryLabels).map(([key, label]) => {
          const isActive = activeCategory === key;
          return (
            <button
              key={key}
              onClick={() => setActiveCategory(key)}
              className={`px-4 py-2 rounded-xl text-xs font-cyber font-bold whitespace-nowrap transition-all cursor-pointer ${
                isActive
                  ? 'bg-gradient-to-r from-purple-900 to-cyan-950 text-cyan-300 border border-cyan-500/50 shadow-[0_0_12px_rgba(6,182,212,0.3)]'
                  : 'bg-[#0C0D16] text-slate-400 hover:text-slate-200 border border-purple-900/40'
              }`}
            >
              {label}
            </button>
          );
        })}
      </div>

      {/* Articles Grid */}
      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
        {filteredArticles.map((article) => {
          const isRead = readGuides.includes(article.id);
          const isBookmarked = bookmarks.includes(article.id);

          return (
            <div
              key={article.id}
              onClick={() => setSelectedArticle(article)}
              className="bg-[#0C0D16] rounded-2xl border border-purple-900/50 p-5 shadow-lg hover:border-cyan-500/60 transition-all cursor-pointer flex flex-col justify-between group relative hover:-translate-y-1"
            >
              {/* Header Badge & Bookmark */}
              <div className="flex items-center justify-between gap-2 mb-3">
                <div className="flex items-center gap-2">
                  <div className="p-2 rounded-xl bg-slate-950 border border-purple-800/50">
                    {getIcon(article.iconName)}
                  </div>
                  <span className="text-[9px] font-cyber font-bold uppercase tracking-widest px-2 py-0.5 rounded bg-purple-950 border border-purple-800 text-purple-300">
                    {categoryLabels[article.category] || article.category}
                  </span>
                </div>

                <div className="flex items-center gap-1.5">
                  {isRead && (
                    <span className="text-[9px] font-cyber font-bold text-emerald-300 bg-emerald-950 border border-emerald-700 px-2 py-0.5 rounded flex items-center gap-1">
                      <CheckCircle2 className="w-3 h-3 text-emerald-400" />
                      Lido
                    </span>
                  )}
                  <button
                    onClick={(e) => toggleBookmark(article.id, e)}
                    className="p-1.5 text-slate-500 hover:text-amber-400 rounded-lg transition-colors cursor-pointer"
                    title="Salvar artigo"
                  >
                    {isBookmarked ? (
                      <BookmarkCheck className="w-4 h-4 text-amber-400 fill-amber-400" />
                    ) : (
                      <Bookmark className="w-4 h-4" />
                    )}
                  </button>
                </div>
              </div>

              {/* Title & Summary */}
              <div className="space-y-2 mb-4">
                <h3 className="font-cyber font-bold text-slate-100 text-base group-hover:text-cyan-300 transition-colors leading-snug">
                  {article.title}
                </h3>
                <p className="text-xs text-slate-400 line-clamp-3 leading-relaxed font-sans">
                  {article.summary}
                </p>
              </div>

              {/* Footer */}
              <div className="pt-3 border-t border-purple-900/30 flex items-center justify-between text-xs text-slate-500 font-mono">
                <div className="flex items-center gap-1.5">
                  <Clock className="w-3.5 h-3.5 text-slate-500" />
                  <span>Leitura: {article.readTime}</span>
                </div>
                <span className="text-cyan-400 font-cyber font-bold text-[11px] flex items-center gap-1 group-hover:translate-x-1 transition-transform">
                  ACESSAR CODEX
                  <ArrowRight className="w-3.5 h-3.5" />
                </span>
              </div>
            </div>
          );
        })}
      </div>

      {filteredArticles.length === 0 && (
        <div className="bg-[#0C0D16] p-12 text-center rounded-2xl border border-purple-900/50">
          <BookOpen className="w-12 h-12 text-purple-600 mx-auto mb-3" />
          <h3 className="text-base font-cyber font-bold text-slate-200">Nenhum registro encontrado no Codex</h3>
          <p className="text-xs text-slate-400 mt-1 font-sans">
            Tente buscar outros termos ou selecione outra categoria.
          </p>
        </div>
      )}

      {/* Article Detail Modal Reader in Gothic Cyber style */}
      {selectedArticle && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-[#0D0E18] w-full max-w-2xl rounded-3xl shadow-2xl overflow-hidden border border-purple-700/60 my-8 animate-scaleUp">
            {/* Modal Header */}
            <div className="bg-gradient-to-r from-purple-950 via-slate-950 to-cyan-950 text-slate-100 p-6 relative border-b border-purple-900/50">
              <button
                onClick={() => setSelectedArticle(null)}
                className="absolute right-4 top-4 p-2 text-slate-400 hover:text-cyan-300 hover:bg-purple-900/50 rounded-full transition-colors cursor-pointer"
                aria-label="Fechar"
              >
                <X className="w-6 h-6" />
              </button>

              <div className="flex items-center gap-2 mb-2">
                <span className="text-[9px] font-cyber font-bold uppercase tracking-widest bg-cyan-950 border border-cyan-800 px-2.5 py-0.5 rounded text-cyan-300">
                  {categoryLabels[selectedArticle.category]}
                </span>
                <span className="text-xs text-slate-400 font-mono">
                  • {selectedArticle.readTime}
                </span>
              </div>

              <h3 className="text-xl sm:text-2xl font-cyber font-bold text-cyan-300 leading-tight">
                {selectedArticle.title}
              </h3>
            </div>

            {/* Modal Body */}
            <div className="p-6 sm:p-8 space-y-6 max-h-[70vh] overflow-y-auto bg-cyber-grid">
              {/* Introduction Content */}
              <div className="space-y-3.5 text-slate-200 text-sm leading-relaxed font-sans">
                {selectedArticle.content.map((paragraph, idx) => (
                  <p key={idx}>{paragraph}</p>
                ))}
              </div>

              {/* Actionable Tips Section */}
              <div className="bg-amber-950/40 border border-amber-500/40 p-5 rounded-2xl space-y-3">
                <h4 className="font-cyber font-bold text-amber-300 text-sm flex items-center gap-2">
                  <Sparkles className="w-4 h-4 text-amber-400" />
                  Diretrizes Práticas de Prevenção:
                </h4>
                <ul className="space-y-2 text-xs text-amber-100 font-sans">
                  {selectedArticle.tips.map((tip, idx) => (
                    <li key={idx} className="flex items-start gap-2">
                      <span className="text-amber-400 font-bold">•</span>
                      <span>{tip}</span>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Tags */}
              <div className="flex flex-wrap gap-1.5 pt-2">
                {selectedArticle.tags.map((tag, idx) => (
                  <span
                    key={idx}
                    className="text-[10px] font-mono bg-purple-950 border border-purple-800 text-purple-300 px-2.5 py-1 rounded"
                  >
                    #{tag}
                  </span>
                ))}
              </div>
            </div>

            {/* Modal Footer */}
            <div className="p-4 sm:p-6 bg-[#080910] border-t border-purple-900/60 flex items-center justify-between gap-4">
              <span className="text-xs text-slate-400 font-sans">
                {readGuides.includes(selectedArticle.id)
                  ? 'Guia registrado em sua jornada!'
                  : 'Ganhe +20 XP ao concluir a leitura.'}
              </span>

              <button
                onClick={() => {
                  onMarkAsRead(selectedArticle.id);
                  setSelectedArticle(null);
                }}
                className={`px-5 py-2.5 rounded-xl text-xs font-cyber font-bold flex items-center gap-2 transition-all cursor-pointer ${
                  readGuides.includes(selectedArticle.id)
                    ? 'bg-emerald-900 border border-emerald-500 text-emerald-200'
                    : 'bg-gradient-to-r from-cyan-500 to-purple-600 hover:from-cyan-400 hover:to-purple-500 text-slate-950 shadow-[0_0_15px_rgba(6,182,212,0.4)]'
                }`}
              >
                <CheckCircle2 className="w-4 h-4" />
                <span>
                  {readGuides.includes(selectedArticle.id)
                    ? 'CONCLUÍDO'
                    : 'REGISTRAR LEITURA (+20 XP)'}
                </span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
