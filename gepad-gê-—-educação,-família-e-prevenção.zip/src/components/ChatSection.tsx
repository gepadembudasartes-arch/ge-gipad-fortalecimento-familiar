import React, { useState, useRef, useEffect } from 'react';
import {
  Send,
  Bot,
  User,
  Sparkles,
  Trash2,
  RefreshCw,
  Volume2,
  VolumeX,
  HelpCircle,
  AlertTriangle,
  PhoneCall,
  Check,
  Terminal
} from 'lucide-react';
import { ChatMessage, UserRole } from '../types';
import { GLogo } from './GLogo';
import { GepadLogo } from './GepadLogo';
import { GERobotAvatar } from './GERobotAvatar';

interface ChatSectionProps {
  userRole: UserRole;
  userName: string;
  onRewardXp: (amount: number) => void;
  setActiveTab: (tab: string) => void;
}

export const ChatSection: React.FC<ChatSectionProps> = ({
  userRole,
  userName,
  onRewardXp,
  setActiveTab,
}) => {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'welcome',
      sender: 'ge',
      text: `Saudações cibernéticas, ${userName}! Eu sou o GÊ, o assistente inteligente do GEPAD GCM Embu das Artes. Como posso orientar você sobre prevenção, resiliência, diálogo em família e apoio com total sigilo hoje?`,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    },
  ]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [speakingMsgId, setSpeakingMsgId] = useState<string | null>(null);

  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, loading]);

  const promptSuggestions = [
    { label: 'Como recusa vapes e drogas com firmeza?', role: 'estudante' },
    { label: 'Como dialogar com meu filho sem brigar?', role: 'pai_mae' },
    { label: 'Dinâmicas de prevenção em sala de aula', role: 'educador' },
    { label: 'Onde encontrar CAPS e Conselho em Embu das Artes?', role: 'comunidade' },
    { label: 'Como lidar com ansiedade e pressão dos amigos?', role: 'estudante' },
  ];

  const handleSend = async (textToSend?: string) => {
    const query = (textToSend || input).trim();
    if (!query || loading) return;

    setErrorMsg(null);
    setInput('');

    const userMsg: ChatMessage = {
      id: Date.now().toString(),
      sender: 'user',
      text: query,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages((prev) => [...prev, userMsg]);
    setLoading(true);

    try {
      const history = messages
        .filter((m) => m.id !== 'welcome')
        .map((m) => ({
          role: m.sender === 'user' ? 'user' : 'model',
          text: m.text,
        }));

      const contextPrefix = `[Perfil do Usuário: ${userRole.toUpperCase()} - Nome: ${userName}] `;
      const messageWithContext = contextPrefix + query;

      const res = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: messageWithContext,
          history,
        }),
      });

      const data = await res.json();

      if (!res.ok) {
        throw new Error(data.error || 'Erro ao obter resposta do assistente.');
      }

      const botMsg: ChatMessage = {
        id: (Date.now() + 1).toString(),
        sender: 'ge',
        text: data.reply,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };

      setMessages((prev) => [...prev, botMsg]);
      onRewardXp(10);
    } catch (err: any) {
      console.error('Erro na resposta do assistente GÊ:', err);
      setErrorMsg(
        err.message || 'Falha de transmissão com o assistente GÊ. Verifique sua conexão e tente novamente.'
      );
    } finally {
      setLoading(false);
    }
  };

  const handleClear = () => {
    if (window.confirm('Deseja reiniciar a sessão do terminal de diálogo GÊ?')) {
      setMessages([
        {
          id: 'welcome-reset',
          sender: 'ge',
          text: `Sessão reiniciada com sucesso. Como posso apoiar você agora, ${userName}?`,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        },
      ]);
    }
  };

  const toggleTextToSpeech = (msgId: string, text: string) => {
    if (!('speechSynthesis' in window)) {
      alert('Seu navegador não suporta leitura de voz.');
      return;
    }

    if (speakingMsgId === msgId) {
      window.speechSynthesis.cancel();
      setSpeakingMsgId(null);
    } else {
      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.lang = 'pt-BR';
      utterance.rate = 1.0;
      utterance.onend = () => setSpeakingMsgId(null);
      utterance.onerror = () => setSpeakingMsgId(null);
      setSpeakingMsgId(msgId);
      window.speechSynthesis.speak(utterance);
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-4 animate-fadeIn pb-12">
      {/* Gothic Cyber Header Info */}
      <div className="bg-[#0C0D16] p-4 sm:p-6 rounded-2xl border border-purple-900/60 shadow-lg flex flex-col sm:flex-row items-center justify-between gap-4">
        <div className="flex items-center gap-3.5">
          <GERobotAvatar size="lg" animated={true} showStatus={true} />
          <GepadLogo size={42} variant="compact" glow={true} />
          <div>
            <h2 className="text-lg font-cyber font-bold text-slate-100 flex items-center gap-2">
              TERMINAL INTELIGENTE IA GÊ
              <span className="text-[9px] font-cyber font-black uppercase bg-cyan-950 border border-cyan-500/50 text-cyan-300 px-2 py-0.5 rounded">
                GEPAD CYBER
              </span>
            </h2>
            <p className="text-xs text-slate-400 font-mono">
              Interface privada de escuta, prevenção e orientação em Embu das Artes.
            </p>
          </div>
        </div>

        <button
          onClick={handleClear}
          className="p-2 text-slate-400 hover:text-rose-400 hover:bg-rose-950/40 border border-purple-900/40 rounded-xl transition-colors text-xs font-cyber flex items-center gap-1.5 cursor-pointer"
          title="Limpar Conversa"
        >
          <Trash2 className="w-4 h-4 text-rose-400" />
          <span className="hidden sm:inline">REINICIAR TERMINAL</span>
        </button>
      </div>

      {/* Main Gothic Cyber Chat Terminal Box */}
      <div className="bg-[#0A0B12] rounded-2xl border border-purple-900/60 shadow-[0_0_30px_rgba(0,0,0,0.9)] flex flex-col h-[540px] overflow-hidden relative">
        {/* Background Logo Watermark */}
        <div className="absolute inset-0 flex items-center justify-center opacity-5 pointer-events-none">
          <GepadLogo size={320} variant="full" glow={false} />
        </div>

        {/* Messages Stream Container */}
        <div className="flex-1 p-4 sm:p-6 overflow-y-auto space-y-4 bg-cyber-grid relative z-10">
          {messages.map((msg) => {
            const isUser = msg.sender === 'user';
            return (
              <div
                key={msg.id}
                className={`flex gap-3 max-w-[88%] sm:max-w-[80%] ${
                  isUser ? 'ml-auto flex-row-reverse' : 'mr-auto'
                }`}
              >
                {/* Avatar */}
                <div className="shrink-0 mt-1">
                  {isUser ? (
                    <div className="w-8 h-8 rounded-xl bg-purple-900 border border-cyan-400 text-cyan-200 flex items-center justify-center font-cyber font-bold text-xs shadow-md">
                      {userName.charAt(0).toUpperCase()}
                    </div>
                  ) : (
                    <GERobotAvatar
                      size="sm"
                      animated={true}
                      showStatus={false}
                      glow={false}
                      speaking={speakingMsgId === msg.id}
                    />
                  )}
                </div>

                {/* Message Bubble */}
                <div
                  className={`rounded-2xl p-4 text-xs sm:text-sm leading-relaxed shadow-lg relative border ${
                    isUser
                      ? 'bg-gradient-to-r from-purple-950 to-indigo-950 border-cyan-500/50 text-slate-100 rounded-tr-none'
                      : 'bg-[#121422]/90 border-purple-800/60 text-slate-200 rounded-tl-none backdrop-blur-md'
                  }`}
                >
                  <div className="flex items-center justify-between gap-4 mb-1.5">
                    <span className={`text-[10px] font-cyber font-bold ${isUser ? 'text-cyan-300' : 'text-purple-300'}`}>
                      {isUser ? userName : 'GÊ • ASSISTENTE CIBERNÉTICO GEPAD'}
                    </span>
                    <div className="flex items-center gap-2">
                      {!isUser && (
                        <button
                          onClick={() => toggleTextToSpeech(msg.id, msg.text)}
                          className="text-slate-400 hover:text-cyan-300 transition-colors cursor-pointer"
                          title="Ouvir áudio"
                        >
                          {speakingMsgId === msg.id ? (
                            <VolumeX className="w-3.5 h-3.5 text-amber-400 animate-pulse" />
                          ) : (
                            <Volume2 className="w-3.5 h-3.5" />
                          )}
                        </button>
                      )}
                      <span className="text-[10px] text-slate-500 font-mono">
                        {msg.timestamp}
                      </span>
                    </div>
                  </div>

                  <div className="whitespace-pre-wrap font-sans">
                    {msg.text}
                  </div>
                </div>
              </div>
            );
          })}

          {/* Loading Indicator */}
          {loading && (
            <div className="flex gap-3 max-w-[80%] mr-auto items-center animate-pulse">
              <div className="w-8 h-8 rounded-xl bg-purple-900 border border-purple-500 text-cyan-300 flex items-center justify-center font-cyber font-black text-xs">
                GÊ
              </div>
              <div className="bg-[#121422] border border-cyan-500/50 rounded-2xl rounded-tl-none p-3.5 text-xs text-cyan-300 flex items-center gap-2.5 shadow-md">
                <Sparkles className="w-4 h-4 text-cyan-400 animate-spin" />
                <span className="font-cyber">Processando diretrizes no Codex GEPAD...</span>
              </div>
            </div>
          )}

          {/* Error Banner */}
          {errorMsg && (
            <div className="bg-rose-950/80 border border-rose-500 text-rose-200 p-3.5 rounded-xl text-xs flex items-center justify-between gap-2">
              <div className="flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0" />
                <span>{errorMsg}</span>
              </div>
              <button
                onClick={() => handleSend()}
                className="text-xs font-cyber font-bold underline text-rose-300 shrink-0 cursor-pointer"
              >
                Reconectar
              </button>
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>

        {/* Cyber Prompt Suggestions Bar */}
        <div className="p-3 bg-[#080910] border-t border-purple-900/50 overflow-x-auto flex gap-2 no-scrollbar relative z-10">
          <span className="text-[9px] font-cyber font-bold text-purple-400 uppercase tracking-widest shrink-0 my-auto mr-1">
            Prompt Cyber:
          </span>
          {promptSuggestions.map((s, idx) => (
            <button
              key={idx}
              onClick={() => handleSend(s.label)}
              disabled={loading}
              className="text-xs bg-[#121422] hover:bg-purple-900/80 hover:text-cyan-300 text-slate-300 font-cyber font-medium px-3.5 py-1.5 rounded-xl border border-purple-800/60 shrink-0 transition-all disabled:opacity-50 cursor-pointer"
            >
              ⚡ {s.label}
            </button>
          ))}
        </div>

        {/* Input Form */}
        <form
          onSubmit={(e) => {
            e.preventDefault();
            handleSend();
          }}
          className="p-3.5 bg-[#090A12] border-t border-purple-900/60 flex gap-2.5 items-center relative z-10"
        >
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder={`Digite seu comando ou dúvida para o GÊ, ${userName}...`}
            disabled={loading}
            className="flex-1 bg-slate-950 border border-purple-800/70 rounded-xl px-4 py-3 text-xs sm:text-sm text-slate-100 placeholder-slate-500 focus:outline-none focus:ring-1 focus:ring-cyan-400 focus:border-cyan-400 transition-all font-sans"
          />
          <button
            type="submit"
            disabled={!input.trim() || loading}
            className="bg-gradient-to-r from-cyan-500 to-purple-600 hover:from-cyan-400 hover:to-purple-500 disabled:opacity-30 text-slate-950 font-cyber font-black p-3.5 rounded-xl transition-all active:scale-95 cursor-pointer shrink-0 border border-cyan-300/40 shadow-[0_0_15px_rgba(6,182,212,0.3)]"
            aria-label="Enviar comando"
          >
            <Send className="w-4 h-4 text-slate-950" />
          </button>
        </form>
      </div>

      {/* Cyber Emergency Warning */}
      <div className="bg-gradient-to-r from-rose-950/80 via-slate-950 to-purple-950/80 border border-rose-600/50 p-4 rounded-xl text-xs text-rose-200 flex items-center justify-between gap-3 shadow-md">
        <div className="flex items-center gap-2.5">
          <HelpCircle className="w-4 h-4 text-rose-400 shrink-0" />
          <span className="font-sans">
            Atendimento imediato de urgência em Embu das Artes: <strong>GCM 153</strong>, <strong>SAMU 192</strong> ou <strong>CVV 188</strong> (24 horas).
          </span>
        </div>
        <button
          onClick={() => setActiveTab('support')}
          className="text-cyan-300 font-cyber font-bold underline shrink-0 hover:text-cyan-200 cursor-pointer"
        >
          Ver Central 24h
        </button>
      </div>
    </div>
  );
};
