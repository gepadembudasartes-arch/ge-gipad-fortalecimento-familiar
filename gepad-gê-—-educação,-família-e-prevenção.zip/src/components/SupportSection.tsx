import React, { useState } from 'react';
import {
  PhoneCall,
  ShieldAlert,
  MapPin,
  Clock,
  ExternalLink,
  HelpCircle,
  ChevronDown,
  ChevronUp,
  AlertCircle,
  Building2,
  Heart
} from 'lucide-react';
import { SupportContact } from '../types';
import { SUPPORT_CONTACTS } from '../data/supportData';
import { GepadLogo } from './GepadLogo';

export const SupportSection: React.FC = () => {
  const [selectedCategory, setSelectedCategory] = useState<string>('todos');
  const [openFaq, setOpenFaq] = useState<number | null>(null);

  const categoryLabels: Record<string, string> = {
    todos: 'Todos os Canais',
    emergencia: 'Urgência & Emergência (24h)',
    gcm: 'Guarda Civil / GEPAD',
    protecao: 'Conselho Tutelar e Proteção',
    psicossocial: 'Saúde Mental e CAPS',
  };

  const filteredContacts = SUPPORT_CONTACTS.filter((c) => {
    if (selectedCategory === 'todos') return true;
    return c.category === selectedCategory;
  });

  const faqs = [
    {
      q: 'O atendimento na rede de apoio de Embu das Artes é gratuito?',
      a: 'Sim! Todos os serviços listados (CAPS, Conselho Tutelar, GCM, SAMU e CVV) são 100% públicos e gratuitos para toda a população de Embu das Artes e região.',
    },
    {
      q: 'Minha família terá sigilo ao procurar o CAPS ou Conselho Tutelar?',
      a: 'Com certeza. Os atendimentos nos CAPS e órgãos de proteção respeitam rigorosamente a privacidade e o sigilo profissional dos usuários e suas famílias.',
    },
    {
      q: 'Como sei se devo ligar para a GCM (153) ou para o SAMU (192)?',
      a: 'Ligue para a GCM 153 para rondas, segurança, situações de perigo ou mediação comunitária. Ligue para o SAMU 192 em emergências médicas, passa-mal agudo ou crises de intoxicação.',
    },
    {
      q: 'Como agendar uma palestra do GEPAD na escola do meu filho?',
      a: 'A gestão da escola pode entrar em contato diretamente com a Central da GCM Embu pelo telefone (11) 4785-3696 para solicitar a visita da equipe do GEPAD.',
    },
  ];

  return (
    <div className="space-y-8 animate-fadeIn pb-12">
      {/* Top Urgent Emergency Bar Gothic Cyber */}
      <div className="bg-gradient-to-r from-rose-950 via-slate-950 to-purple-950 border border-rose-600/60 text-slate-100 p-6 sm:p-8 rounded-3xl shadow-[0_0_30px_rgba(244,63,94,0.3)] relative overflow-hidden">
        <div className="relative z-10 space-y-4">
          <div className="flex items-center gap-3">
            <GepadLogo size={42} variant="compact" glow={true} />
            <div className="inline-flex items-center gap-2 bg-rose-900/80 border border-rose-500/60 px-3 py-1 rounded-lg text-rose-200 text-xs font-cyber font-bold">
              <ShieldAlert className="w-4 h-4 text-rose-400 animate-pulse" />
              <span>CENTRAL DE EMERGÊNCIA E APOIO IMEDIATO (24H)</span>
            </div>
          </div>

          <h2 className="text-2xl sm:text-3xl font-cyber font-bold tracking-wider text-rose-200">
            Precisa de Ajuda Agora em Embu das Artes?
          </h2>

          <p className="text-slate-300 text-xs sm:text-sm max-w-2xl font-sans leading-relaxed">
            Em momentos de risco, violência, crise psicológica ou urgência familiar, acione os canais oficiais de proteção 24h.
          </p>

          <div className="grid sm:grid-cols-3 gap-3 pt-2">
            <a
              href="tel:153"
              className="bg-slate-950 border border-cyan-500/60 text-slate-100 p-4 rounded-2xl font-cyber font-bold text-center hover:bg-purple-950 transition-all flex flex-col items-center justify-center gap-1 shadow-[0_0_15px_rgba(6,182,212,0.3)] group cursor-pointer"
            >
              <span className="text-[10px] uppercase text-cyan-400 font-mono">GCM EMBU DAS ARTES</span>
              <span className="text-3xl font-black text-cyan-300 group-hover:scale-105 transition-transform">153</span>
              <span className="text-[10px] text-slate-400 font-sans">Emergência & Ronda</span>
            </a>

            <a
              href="tel:192"
              className="bg-slate-950 border border-rose-500/60 text-slate-100 p-4 rounded-2xl font-cyber font-bold text-center hover:bg-rose-950/60 transition-all flex flex-col items-center justify-center gap-1 shadow-[0_0_15px_rgba(244,63,94,0.3)] group cursor-pointer"
            >
              <span className="text-[10px] uppercase text-rose-400 font-mono">SAMU SAÚDE</span>
              <span className="text-3xl font-black text-rose-400 group-hover:scale-105 transition-transform">192</span>
              <span className="text-[10px] text-slate-400 font-sans">Urgência Médica</span>
            </a>

            <a
              href="tel:188"
              className="bg-slate-950 border border-emerald-500/60 text-slate-100 p-4 rounded-2xl font-cyber font-bold text-center hover:bg-emerald-950/60 transition-all flex flex-col items-center justify-center gap-1 shadow-[0_0_15px_rgba(16,185,129,0.3)] group cursor-pointer"
            >
              <span className="text-[10px] uppercase text-emerald-400 font-mono">CVV APOIO EMOCIONAL</span>
              <span className="text-3xl font-black text-emerald-300 group-hover:scale-105 transition-transform">188</span>
              <span className="text-[10px] text-slate-400 font-sans">Sigilo & Escuta 24h</span>
            </a>
          </div>
        </div>
      </div>

      {/* Category Tabs */}
      <div className="flex gap-2 overflow-x-auto pb-1 no-scrollbar">
        {Object.entries(categoryLabels).map(([key, label]) => {
          const isActive = selectedCategory === key;
          return (
            <button
              key={key}
              onClick={() => setSelectedCategory(key)}
              className={`px-4 py-2 rounded-xl text-xs font-cyber font-bold whitespace-nowrap transition-all cursor-pointer ${
                isActive
                  ? 'bg-gradient-to-r from-purple-900 to-cyan-950 text-cyan-300 border border-cyan-500/50 shadow-[0_0_12px_rgba(6,182,212,0.3)]'
                  : 'bg-[#0C0D16] text-slate-400 hover:text-slate-200 border border-purple-900/40'
              }`}
            >
              {label}
            </button>
          );
        })}
      </div>

      {/* Contact Cards Directory */}
      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
        {filteredContacts.map((contact) => (
          <div
            key={contact.id}
            className={`bg-[#0C0D16] p-6 rounded-2xl border shadow-lg flex flex-col justify-between transition-all hover:border-cyan-400 ${
              contact.urgent ? 'border-rose-600/60' : 'border-purple-900/50'
            }`}
          >
            <div className="space-y-3">
              <div className="flex items-start justify-between gap-2">
                <span className="text-[9px] font-cyber font-bold uppercase tracking-widest bg-purple-950 text-purple-300 border border-purple-800 px-2.5 py-0.5 rounded">
                  {categoryLabels[contact.category]}
                </span>
                {contact.urgent && (
                  <span className="text-[9px] font-cyber font-bold uppercase bg-rose-950 text-rose-300 border border-rose-700 px-2 py-0.5 rounded">
                    24 HORAS
                  </span>
                )}
              </div>

              <h3 className="font-cyber font-bold text-slate-100 text-base leading-snug">
                {contact.name}
              </h3>

              <p className="text-xs text-slate-300 leading-relaxed font-sans">
                {contact.description}
              </p>

              <div className="space-y-1.5 pt-2 text-xs text-slate-400 font-mono border-t border-purple-900/30">
                {contact.address && (
                  <div className="flex items-start gap-1.5">
                    <MapPin className="w-3.5 h-3.5 text-cyan-400 shrink-0 mt-0.5" />
                    <span>{contact.address}</span>
                  </div>
                )}
                {contact.hours && (
                  <div className="flex items-center gap-1.5">
                    <Clock className="w-3.5 h-3.5 text-purple-400 shrink-0" />
                    <span>{contact.hours}</span>
                  </div>
                )}
              </div>
            </div>

            {/* Tap to Call Button */}
            <div className="pt-4 mt-4 border-t border-purple-900/30">
              <a
                href={`tel:${contact.phone.replace(/[^0-9]/g, '')}`}
                className="w-full bg-gradient-to-r from-cyan-500 to-purple-600 hover:from-cyan-400 hover:to-purple-500 text-slate-950 font-cyber font-bold py-2.5 px-4 rounded-xl text-xs flex items-center justify-center gap-2 shadow-[0_0_12px_rgba(6,182,212,0.3)] transition-all cursor-pointer"
              >
                <PhoneCall className="w-4 h-4 text-slate-950" />
                <span>Ligar: {contact.phone}</span>
              </a>
            </div>
          </div>
        ))}
      </div>

      {/* Frequently Asked Questions */}
      <section className="bg-[#0C0D16] p-6 sm:p-8 rounded-3xl border border-purple-900/60 shadow-lg space-y-6">
        <div className="flex items-center gap-2">
          <HelpCircle className="w-5 h-5 text-cyan-400" />
          <h3 className="text-xl font-cyber font-bold text-slate-100">
            Perguntas Frequentes sobre a Rede de Apoio
          </h3>
        </div>

        <div className="space-y-3 font-sans">
          {faqs.map((faq, idx) => {
            const isOpen = openFaq === idx;
            return (
              <div
                key={idx}
                className="border border-purple-900/50 rounded-2xl overflow-hidden bg-slate-950 transition-colors"
              >
                <button
                  onClick={() => setOpenFaq(isOpen ? null : idx)}
                  className="w-full p-4 text-left font-bold text-xs sm:text-sm text-slate-200 flex items-center justify-between gap-3 hover:bg-purple-950/40 cursor-pointer"
                >
                  <span>{faq.q}</span>
                  {isOpen ? (
                    <ChevronUp className="w-4 h-4 text-cyan-400 shrink-0" />
                  ) : (
                    <ChevronDown className="w-4 h-4 text-slate-500 shrink-0" />
                  )}
                </button>
                {isOpen && (
                  <div className="p-4 bg-[#080910] border-t border-purple-900/40 text-xs sm:text-sm text-slate-300 leading-relaxed font-sans">
                    {faq.a}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </section>
    </div>
  );
};
