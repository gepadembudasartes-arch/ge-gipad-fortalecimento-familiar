import React, { useState } from 'react';
import {
  Home,
  Bot,
  BookOpen,
  Gamepad2,
  Users,
  PhoneCall,
  User,
  Award,
  Sparkles,
  Menu,
  X,
  ShieldAlert,
  Zap
} from 'lucide-react';
import { ActiveTab, UserRole } from '../types';
import { GLogo } from './GLogo';
import { GepadLogo } from './GepadLogo';

interface HeaderProps {
  activeTab: ActiveTab;
  setActiveTab: (tab: ActiveTab) => void;
  xp: number;
  level: number;
  userRole: UserRole;
  setUserRole: (role: UserRole) => void;
  userName: string;
}

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  setActiveTab,
  xp,
  level,
  userRole,
  setUserRole,
  userName,
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navItems: { id: ActiveTab; label: string; icon: React.ReactNode; badge?: string }[] = [
    { id: 'home', label: 'Início', icon: <Home className="w-4 h-4" /> },
    { id: 'chat', label: 'IA GÊ', icon: <Bot className="w-4 h-4" />, badge: 'NEON IA' },
    { id: 'guides', label: 'Guias & Codex', icon: <BookOpen className="w-4 h-4" /> },
    { id: 'games', label: 'Desafios & Quiz', icon: <Gamepad2 className="w-4 h-4" /> },
    { id: 'community', label: 'Mural do Encontro', icon: <Users className="w-4 h-4" /> },
    { id: 'support', label: 'Rede 24h', icon: <PhoneCall className="w-4 h-4" /> },
    { id: 'profile', label: 'Minha Jornada', icon: <User className="w-4 h-4" /> },
  ];

  const roleLabels: Record<UserRole, string> = {
    estudante: 'Estudante',
    pai_mae: 'Pai / Mãe',
    educador: 'Educador(a)',
    comunidade: 'Comunidade',
  };

  return (
    <header className="sticky top-0 z-40 bg-[#090A10]/90 backdrop-blur-xl border-b border-purple-900/40 shadow-[0_4px_25px_rgba(0,0,0,0.8)]">
      {/* Top Banner for GCM Embu das Artes in Gothic Cyber style */}
      <div className="bg-gradient-to-r from-purple-950 via-slate-950 to-cyan-950 text-slate-300 text-xs px-4 py-1.5 border-b border-purple-900/30">
        <div className="flex items-center justify-between max-w-7xl mx-auto w-full">
          <div className="flex items-center gap-2">
            <span className="relative flex h-2.5 w-2.5">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-cyan-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-cyan-500"></span>
            </span>
            <span className="font-cyber text-[11px] tracking-wide text-cyan-300">
              GCM EMBU DAS ARTES <span className="text-purple-400">•</span> GEPAD DIGITAL
            </span>
          </div>

          <div className="hidden sm:flex items-center gap-4">
            <button
              onClick={() => setActiveTab('support')}
              className="hover:text-amber-300 flex items-center gap-1.5 text-rose-400 font-cyber font-bold transition-colors cursor-pointer"
            >
              <ShieldAlert className="w-3.5 h-3.5 text-rose-500 animate-pulse" />
              <span>EMERGÊNCIA GCM: 153</span>
            </button>
            <span className="text-purple-800">|</span>
            <span className="text-slate-400 text-[11px] font-mono">EMBU DAS ARTES - SP</span>
          </div>
        </div>
      </div>

      {/* Main Header Container */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3">
        <div className="flex items-center justify-between gap-4">
          {/* Logo & Brand with GEPAD Emblem & Mascot */}
          <div
            onClick={() => setActiveTab('home')}
            className="cursor-pointer flex items-center gap-3 group select-none"
          >
            {/* GEPAD Logo */}
            <div className="relative group-hover:scale-105 transition-transform duration-300">
              <div className="absolute -inset-1 rounded-full bg-gradient-to-r from-purple-600 to-cyan-500 opacity-30 group-hover:opacity-80 blur-xs transition duration-300"></div>
              <GepadLogo size={46} variant="compact" glow={true} />
            </div>

            {/* Division Divider */}
            <div className="h-9 w-px bg-purple-900/60 hidden sm:block"></div>

            {/* Mascot GÊ */}
            <div className="hidden sm:flex items-center gap-2">
              <GLogo size={36} />
              <div>
                <div className="flex items-center gap-1.5">
                  <h1 className="text-lg font-cyber font-black tracking-wider text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 via-purple-300 to-rose-400">
                    GÊ
                  </h1>
                  <span className="text-[9px] font-cyber font-extrabold uppercase tracking-widest px-1.5 py-0.5 bg-purple-950 border border-purple-700/60 text-purple-300 rounded">
                    GEPAD
                  </span>
                </div>
                <p className="text-[10px] text-slate-400 font-mono tracking-tight">
                  GERAÇÃO • EDUCAÇÃO • ENCONTRO
                </p>
              </div>
            </div>
          </div>

          {/* Desktop Controls (XP & Role) */}
          <div className="hidden md:flex items-center gap-3">
            {/* User Profile Pill */}
            <div
              onClick={() => setActiveTab('profile')}
              className="flex items-center gap-2 bg-slate-900/80 border border-purple-800/50 rounded-xl px-3 py-1.5 cursor-pointer hover:border-cyan-500/60 hover:bg-slate-800/90 transition-all shadow-[0_0_12px_rgba(139,92,246,0.15)]"
            >
              <div className="w-7 h-7 rounded-lg bg-gradient-to-tr from-purple-700 via-purple-900 to-cyan-600 text-cyan-200 flex items-center justify-center font-cyber font-bold text-xs border border-purple-500/40">
                {userName.charAt(0).toUpperCase()}
              </div>
              <div className="text-left">
                <p className="text-xs font-cyber font-bold text-slate-200 leading-none">{userName}</p>
                <p className="text-[10px] text-cyan-400 font-mono leading-tight mt-0.5">{roleLabels[userRole]}</p>
              </div>
            </div>

            {/* Role Switcher Select */}
            <select
              value={userRole}
              onChange={(e) => setUserRole(e.target.value as UserRole)}
              className="text-xs bg-slate-900 border border-purple-800/60 rounded-xl px-2.5 py-1.5 text-slate-300 font-cyber hover:border-cyan-400 focus:outline-none focus:ring-1 focus:ring-cyan-400"
              aria-label="Perfil do Usuário"
            >
              <option value="estudante">Perfil: Estudante</option>
              <option value="pai_mae">Perfil: Pai / Mãe</option>
              <option value="educador">Perfil: Educador(a)</option>
              <option value="comunidade">Perfil: Comunidade</option>
            </select>

            {/* XP Badge Gothic Cyber */}
            <div
              onClick={() => setActiveTab('profile')}
              className="flex items-center gap-1.5 bg-amber-950/40 border border-amber-500/50 text-amber-300 px-3 py-1.5 rounded-xl text-xs font-cyber font-bold cursor-pointer hover:bg-amber-900/50 transition-colors shadow-[0_0_15px_rgba(245,158,11,0.2)]"
            >
              <Sparkles className="w-4 h-4 text-amber-400 animate-pulse" />
              <span>Nível {level}</span>
              <span className="text-amber-500/80 font-mono">({xp} XP)</span>
            </div>
          </div>

          {/* Mobile Menu Button */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="md:hidden p-2 rounded-xl text-slate-300 hover:bg-purple-950 border border-purple-900/60 focus:outline-none"
            aria-label="Alternar Menu"
          >
            {mobileMenuOpen ? <X className="w-6 h-6 text-cyan-400" /> : <Menu className="w-6 h-6 text-purple-300" />}
          </button>
        </div>

        {/* Desktop Navigation Tabs */}
        <nav className="hidden md:flex items-center gap-1 mt-3 pt-2.5 border-t border-purple-900/30">
          {navItems.map((item) => {
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id)}
                className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-cyber font-bold transition-all relative cursor-pointer ${
                  isActive
                    ? 'bg-gradient-to-r from-purple-900 via-indigo-950 to-cyan-950 text-cyan-300 border border-cyan-500/50 shadow-[0_0_15px_rgba(6,182,212,0.3)]'
                    : 'text-slate-400 hover:text-cyan-300 hover:bg-purple-950/40 border border-transparent'
                }`}
              >
                {item.icon}
                <span>{item.label}</span>
                {item.badge && (
                  <span
                    className={`text-[8px] font-cyber font-extrabold uppercase px-1.5 py-0.5 rounded ${
                      isActive ? 'bg-cyan-400 text-slate-950' : 'bg-purple-900/80 text-purple-200 border border-purple-700/60'
                    }`}
                  >
                    {item.badge}
                  </span>
                )}
              </button>
            );
          })}
        </nav>
      </div>

      {/* Mobile Menu Dropdown */}
      {mobileMenuOpen && (
        <div className="md:hidden bg-[#0C0D14] border-b border-purple-900/60 px-4 pt-3 pb-5 space-y-3 animate-fadeIn">
          <div className="flex items-center justify-between pb-3 border-b border-purple-900/40">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-lg bg-purple-900 text-cyan-300 font-cyber font-bold flex items-center justify-center text-xs border border-purple-500/40">
                {userName.charAt(0).toUpperCase()}
              </div>
              <div>
                <p className="text-xs font-cyber font-bold text-slate-200">{userName}</p>
                <p className="text-[10px] text-cyan-400 font-mono">{roleLabels[userRole]}</p>
              </div>
            </div>
            <div className="flex items-center gap-1.5 bg-amber-950/60 border border-amber-500/40 text-amber-300 px-2.5 py-1 rounded-lg text-xs font-cyber font-bold">
              <Award className="w-3.5 h-3.5 text-amber-400" />
              <span>Nível {level} ({xp} XP)</span>
            </div>
          </div>

          <div>
            <label className="text-[10px] font-cyber font-bold text-purple-400 uppercase tracking-widest block mb-1">
              Perfil do Usuário
            </label>
            <select
              value={userRole}
              onChange={(e) => setUserRole(e.target.value as UserRole)}
              className="w-full text-xs bg-slate-900 border border-purple-800 rounded-lg p-2 font-cyber text-slate-200"
            >
              <option value="estudante">Estudante</option>
              <option value="pai_mae">Pai / Mãe</option>
              <option value="educador">Educador(a)</option>
              <option value="comunidade">Comunidade</option>
            </select>
          </div>

          <div className="space-y-1.5 pt-1">
            {navItems.map((item) => {
              const isActive = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => {
                    setActiveTab(item.id);
                    setMobileMenuOpen(false);
                  }}
                  className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl text-xs font-cyber font-bold ${
                    isActive
                      ? 'bg-gradient-to-r from-purple-900 to-cyan-950 text-cyan-300 border border-cyan-500/50'
                      : 'text-slate-300 hover:bg-purple-950/60 border border-transparent'
                  }`}
                >
                  <div className="flex items-center gap-2.5">
                    {item.icon}
                    <span>{item.label}</span>
                  </div>
                  {item.badge && (
                    <span className="text-[9px] bg-cyan-400 text-slate-950 font-extrabold px-1.5 py-0.5 rounded">
                      {item.badge}
                    </span>
                  )}
                </button>
              );
            })}
          </div>
        </div>
      )}
    </header>
  );
};
