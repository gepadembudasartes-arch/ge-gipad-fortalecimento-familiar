import { GuideArticle } from '../types';

export const GUIDES_DATA: GuideArticle[] = [
  {
    id: 'dizer-nao-com-confianca',
    title: 'Como Dizer "Não" com Confiança e Firmeza',
    category: 'jovens',
    summary: 'Aprenda estratégias práticas para impor limites e resistir à pressão dos colegas sem perder amizades reais.',
    readTime: '4 min',
    iconName: 'ShieldCheck',
    tags: ['Pressão Social', 'Autonomia', 'Amizades'],
    content: [
      'Em muitos momentos da adolescência e juventude, surge a tentação ou a cobrança do grupo para experimentar substâncias ou adotar comportamentos de risco.',
      'Dizer "não" não significa ser chato ou anti-social. Pelo contrário: é uma demonstração de personalidade forte, auto-respeito e liderança.',
      'Sua saúde e seu futuro valem muito mais do que a aprovação momentânea de quem não se importa de verdade com o seu bem-estar.'
    ],
    tips: [
      'Use a técnica do "Não direto": "Valeu, mas eu não curto." Sem precisar dar mil justificativas.',
      'Sugira uma alternativa positiva: "Não quero beber isso, mas bora jogar uma partida de futebol/ouvir uma música?"',
      'Defina seus limites com antecedência: Sabendo o que você quer para a sua vida, fica muito mais fácil recusar o que te prejudica.',
      'Mantenha por perto amigos verdadeiros: Amigos reais respeitam suas decisões e não te forçam a fazer nada nocivo.'
    ]
  },
  {
    id: 'dialogo-em-familia',
    title: 'Fortalecendo o Diálogo em Família: Regras e Afeto',
    category: 'pais',
    summary: 'Guia prático para pais e responsáveis construírem um ambiente seguro, com acolhimento e limites claros.',
    readTime: '6 min',
    iconName: 'HeartHandshake',
    tags: ['Família', 'Comunicação', 'Acolhimento'],
    content: [
      'A prevenção ao uso de drogas começa dentro de casa, por meio de vínculos afetivos sólidos, escuta ativa e convivência respeitosa.',
      'Estudos mostram que jovens que se sentem ouvidos e compreendidos pelos pais têm significativamente menos chances de buscar refúgio em substâncias tóxicas.',
      'Criar um ambiente seguro não significa ausência de limites, mas sim o equilíbrio perfeito entre afeto, acompanhamento e disciplina positiva.'
    ],
    tips: [
      'Escute sem julgar imediatamente: Deixe seu filho falar sobre seus sentimentos e dúvidas sem interromper com broncas antecipadas.',
      'Compartilhe refeições e momentos simples: A rotina diária é a melhor oportunidade para conversas espontâneas e afetuosas.',
      'Seja o exemplo: As atitudes dos adultos em relação a bebidas, medicamentos e estresse ensinam mais do que discursos.',
      'Monitore com respeito: Conheça os amigos do seu filho, saiba onde ele está, mas mantenha a confiança mútua.'
    ]
  },
  {
    id: 'sinais-de-alerta-e-mudancas',
    title: 'Identificando Sinais de Alerta e Alterações Comportamentais',
    category: 'pais',
    summary: 'Como diferenciar oscilações típicas da juventude de sinais que exigem atenção e apoio profissional.',
    readTime: '5 min',
    iconName: 'AlertCircle',
    tags: ['Sinais de Alerta', 'Saúde Mental', 'Atenção'],
    content: [
      'Muitas alterações de humor são normais na fase do desenvolvimento dos jovens. Porém, quando ocorrem mudanças bruscas e persistentes no padrão de comportamento, é fundamental acender o sinal de alerta.',
      'A intervenção precoce e o apoio afetivo evitam o agravamento de quadros de sofrimento psíquico ou dependência.'
    ],
    tips: [
      'Queda repentina no rendimento escolar ou faltas frequentes sem justificativa.',
      'Isolamento extremo, abandono de hobbies e esportes que antes adorava.',
      'Mudança drástica no grupo de amizades e recusa em apresentar novos colegas.',
      'Alterações marcantes no sono e apetite, ou agressividade desproporcional.',
      'O que fazer: Aproxime-se com carinho e procure a rede de apoio pública (CAPS, Orientação Escolar, GEPAD).'
    ]
  },
  {
    id: 'ambiente-escolar-e-prevencao',
    title: 'O Papel do Educador na Prevenção Primária',
    category: 'educadores',
    summary: 'Estratégias pedagógicas para promover habilidades de vida, empatia e cidadania dentro da sala de aula.',
    readTime: '6 min',
    iconName: 'GraduationCap',
    tags: ['Escola', 'Pedagogia', 'Prevenção Primária'],
    content: [
      'A escola é um espaço privilegiado para a promoção da saúde, desenvolvimento socioemocional e construção de valores comunitários.',
      'A prevenção mais eficaz não foca no medo, mas sim no fortalecimento das Habilidades de Vida: pensamento crítico, tomada de decisão, empatia e resolução de problemas.',
      'O projeto GEPAD atua em parceria com as escolas municipais e estaduais de Embu das Artes para criar ambientes protegidos.'
    ],
    tips: [
      'Integre temas transversais de saúde e cidadania nas disciplinas curriculares.',
      'Promova rodas de conversa sobre projetos de futuro, sonhos e autoconhecimento.',
      'Esteja atento aos alunos mais silenciosos ou em situação de vulnerabilidade.',
      'Mantenha um canal de diálogo constante com a gestão escolar e os serviços de saúde locais.'
    ]
  },
  {
    id: 'papel-da-gcm-e-gepad',
    title: 'GCM e GEPAD Embu das Artes: Proteção e Cidadania',
    category: 'cidadania',
    summary: 'Conheça a atuação do Grupo de Educação e Prevenção às Drogas da Guarda Civil Municipal.',
    readTime: '4 min',
    iconName: 'Building2',
    tags: ['GCM', 'GEPAD', 'Embu das Artes', 'Segurança Pública'],
    content: [
      'O GEPAD (Grupo de Educação e Prevenção às Drogas) é um projeto pioneiro da Guarda Civil Municipal de Embu das Artes/SP.',
      'Nosso compromisso vai além do patrulhamento: atuamos preventivamente nas escolas, praças e comunidades por meio de palestras, dinâmicas, teatro educativo e orientação familiar.',
      'Acreditamos que a verdadeira segurança pública se constrói com educação, presença comunitária, acolhimento e valorização da vida.'
    ],
    tips: [
      'A GCM de Embu das Artes atende pelo telefone de emergência 153 e (11) 4785-3696.',
      'Escolas podem agendar palestras e visitas do GEPAD diretamente com a coordenação.',
      'Denúncias anônimas de pontos de venda e exploração podem ser feitas com segurança.'
    ]
  },
  {
    id: 'mitos-e-verdades-substancias',
    title: 'Mitos e Verdades sobre Álcool, Vapes e Substâncias',
    category: 'jovens',
    summary: 'Desmistificando ideias erradas sobre cigarros eletrônicos, bebidas e energéticos com dados científicos.',
    readTime: '5 min',
    iconName: 'HelpCircle',
    tags: ['Mitos e Verdades', 'Vape', 'Saúde Físia'],
    content: [
      'Existem muitos mitos espalhados pelas redes sociais sobre substâncias. Entender a realidade é o primeiro passo para fazer escolhas inteligentes.',
      'Mito 1: "Vape (cigarro eletrônico) é só vapor de água e não faz mal." -> FALSO! Vapes contêm nicotina concentrada, substâncias tóxicas e metais pesados que causam dependência severa e lesões pulmonares.',
      'Mito 2: "Álcool não é droga porque é liberado." -> FALSO! O álcool é uma substância psicoativa que causa dependência, acidentes e danos cerebrais sérios, especialmente em cérebros em desenvolvimento.'
    ],
    tips: [
      'Procure fontes de informação confiáveis e científicas.',
      'Lembre-se: colocar a sua saúde em risco por um modismo nunca vale a pena.',
      'Pratique esportes, artes, cultura e lazer saudável com amigos.'
    ]
  }
];
