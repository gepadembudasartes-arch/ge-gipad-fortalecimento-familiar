import { Pledge, GepadEvent } from '../types';

export const INITIAL_PLEDGES: Pledge[] = [
  {
    id: 'p1',
    authorName: 'Camila S.',
    authorRole: 'Estudante (E.E. Eng. Rodolfo José Pinho)',
    message: 'Meu compromisso é praticar dança, cuidar da minha mente e sempre apoiar meus amigos quando eles estiverem passando por momentos difíceis!',
    category: 'Jovens',
    likes: 18,
    date: 'Hoje'
  },
  {
    id: 'p2',
    authorName: 'Roberto M.',
    authorRole: 'Pai de 2 alunos',
    message: 'Comprometo-me a reservar ao menos 30 minutos por dia para conversar com meus filhos sem celular, ouvindo seus sonhos e preocupações.',
    category: 'Família',
    likes: 24,
    date: 'Ontem'
  },
  {
    id: 'p3',
    authorName: 'Prof. Ana Lúcia',
    authorRole: 'Educadora em Embu das Artes',
    message: 'Na minha sala de aula, o respeito, a empatia e a escuta ativa sempre vêm em primeiro lugar. Escola é lugar de acolhimento!',
    category: 'Educação',
    likes: 31,
    date: 'Há 2 dias'
  },
  {
    id: 'p4',
    authorName: 'GCM Silva',
    authorRole: 'Equipe GEPAD Embu das Artes',
    message: 'Contem sempre com a Guarda Civil Municipal para orientar, proteger e construir um futuro livre de drogas para nossos jovens!',
    category: 'GEPAD',
    likes: 45,
    date: 'Há 3 dias'
  }
];

export const GEPAD_EVENTS: GepadEvent[] = [
  {
    id: 'ev1',
    title: 'Palestra GEPAD: Família e Prevenção no Século XXI',
    location: 'E.M. Valdelice Prass - Parque Pirajussara',
    date: '18 de Agosto',
    time: '19:00',
    targetAudience: 'Pais, Mães e Responsáveis',
    description: 'Encontro presencial com a equipe do GEPAD para debater limites, afeto, uso de telas e prevenção ao uso de e-cigs/vapes.'
  },
  {
    id: 'ev2',
    title: 'Oficina Interativa: Escolhas e Projetos de Vida',
    location: 'E.E. Moscato - Jd. Santa Emília',
    date: '22 de Agosto',
    time: '10:00',
    targetAudience: 'Estudantes do 8º e 9º ano',
    description: 'Atividade dinâmica com o mascote GÊ, teatro interativo e roda de conversa sobre autoestima e futuro.'
  },
  {
    id: 'ev3',
    title: 'Caminhada Comunitária pela Vida e Esporte',
    location: 'Parque do Lago Francisco Rizzo',
    date: '30 de Agosto',
    time: '08:30',
    targetAudience: 'Toda a Comunidade de Embu das Artes',
    description: 'Evento de integração com corrida, caminhada, prestação de serviços de saúde e apresentações culturais da GCM.'
  }
];
