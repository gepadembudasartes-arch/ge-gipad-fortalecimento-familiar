import { SupportContact } from '../types';

export const SUPPORT_CONTACTS: SupportContact[] = [
  {
    id: 'gcm-embu',
    name: 'Guarda Civil Municipal - Embu das Artes (GCM & GEPAD)',
    category: 'gcm',
    phone: '153',
    neighborhood: 'Centro / Atendimento Geral',
    hours: '24 horas por dia',
    description: 'Atendimento de emergência, rondas escolares, palestras preventivas do GEPAD e proteção comunitária.',
    urgent: true
  },
  {
    id: 'gcm-tel-fixo',
    name: 'Central de Operações GCM Embu das Artes',
    category: 'gcm',
    phone: '(11) 4785-3696',
    neighborhood: 'Av. Elias Yazbek, Centro - Embu das Artes',
    hours: '24 horas',
    description: 'Linha direta de atendimento e agendamento de palestras educativas do GEPAD.',
    urgent: false
  },
  {
    id: 'conselho-tutelar-1',
    name: 'Conselho Tutelar I - Centro/Sede',
    category: 'protecao',
    phone: '(11) 4704-4544',
    address: 'Rua Nossa Senhora do Rosário, 203 - Centro, Embu das Artes',
    hours: 'Segunda a Sexta, das 08h às 17h',
    description: 'Garantia dos direitos da criança e do adolescente em situações de vulnerabilidade ou ameaça.',
    urgent: true
  },
  {
    id: 'conselho-tutelar-2',
    name: 'Conselho Tutelar II - Santo Eduardo',
    category: 'protecao',
    phone: '(11) 4781-0814',
    address: 'Estrada de Itapecerica a Campo Limpo - Jd. Santo Eduardo',
    hours: 'Segunda a Sexta, das 08h às 17h',
    description: 'Atendimento e proteção aos direitos de crianças e adolescentes na região do Santo Eduardo e Vazame.',
    urgent: false
  },
  {
    id: 'caps-i',
    name: 'CAPS i (Infanto-Juvenil) - Embu das Artes',
    category: 'psicossocial',
    phone: '(11) 4781-6302',
    address: 'Av. João Paulo II, 1968 - Jd. Silva Ramos',
    hours: 'Segunda a Sexta, das 07h às 17h',
    description: 'Apoio especializado em saúde mental para crianças, adolescentes e suas famílias.',
    urgent: false
  },
  {
    id: 'caps-ad',
    name: 'CAPS AD (Álcool e Outras Drogas)',
    category: 'psicossocial',
    phone: '(11) 4704-5100',
    address: 'Rua Rocio, 51 - Jd. Marly, Embu das Artes',
    hours: 'Segunda a Sexta, das 07h às 17h',
    description: 'Acolhimento humanizado, tratamento e reinserção social para dependência química.',
    urgent: false
  },
  {
    id: 'samu',
    name: 'SAMU - Serviço de Atendimento Móvel de Urgência',
    category: 'emergencia',
    phone: '192',
    hours: '24 horas por dia',
    description: 'Urgências e emergências de saúde, crises agudas e intoxicações.',
    urgent: true
  },
  {
    id: 'cvv',
    name: 'CVV - Centro de Valorização da Vida',
    category: 'emergencia',
    phone: '188',
    hours: '24 horas - Gratuito e Sigiloso',
    description: 'Apoio emocional e prevenção do suicídio. Atendimento afetuoso e anônimo por telefone ou chat.',
    urgent: true
  },
  {
    id: 'creas',
    name: 'CREAS - Centro de Referência Especializado de Assistência Social',
    category: 'protecao',
    phone: '(11) 4785-3580',
    address: 'Rua do Mandacaru, 230 - Jd. Magali',
    hours: 'Segunda a Sexta, das 08h às 17h',
    description: 'Acompanhamento social a famílias e indivíduos em situação de risco, violência ou direitos violados.',
    urgent: false
  }
];
