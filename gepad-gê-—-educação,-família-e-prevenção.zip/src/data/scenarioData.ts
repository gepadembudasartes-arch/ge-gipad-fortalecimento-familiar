import { ScenarioNode } from '../types';

export const SCENARIO_TREE: Record<string, ScenarioNode> = {
  start: {
    id: 'start',
    character: 'Lucas, 15 anos',
    title: 'A Festa de Sexta-Feira',
    situation: 'É sexta-feira à noite. Lucas foi convidado para o aniversário de um colega da escola em Embu das Artes. Ao chegar, percebe que um grupo de veteranos trouxe bebida alcoólica e um vape, e estão oferecendo para quem chega. Um colega diz: "Pega aí, Lucas! Todo mundo tá usando, não vai ficar de fora, né?"',
    choices: [
      {
        text: 'Agradecer educadamente e dizer: "Valeu cara, mas eu prefiro ficar no refrigerante mesmo!"',
        nextId: 'refusai_direta',
        xpGain: 30,
        feedback: 'Excelente escolha! Lucas manteve a firmeza sem criar atritos.'
      },
      {
        text: 'Ficar hesitante, com medo de ser julgado, e aceitar para parecer "legal".',
        nextId: 'aceita_pressao',
        xpGain: 5,
        feedback: 'A pressão dos colegas pode ser forte, mas ceder por medo prejudica sua saúde.'
      },
      {
        text: 'Mudar de assunto e chamar alguns amigos para jogar videogame ou ouvir música no quintal.',
        nextId: 'muda_foco',
        xpGain: 25,
        feedback: 'Ótima sacada! Redirecionar o foco para uma atividade divertida alivia a pressão.'
      }
    ]
  },
  refusai_direta: {
    id: 'refusai_direta',
    character: 'Lucas, 15 anos',
    title: 'Respeito e Autonomia',
    situation: 'O colega insiste mais uma vez, mas Lucas mantém o sorriso no rosto e pega um suco na mesa. Dois outros colegas que estavam com receio veem a atitude de Lucas e também decidem recusar a bebida. Lucas percebe que sua postura inspirou outros a dizerem não!',
    choices: [
      {
        text: 'Aproveitar a festa dançando e conversando com os amigos que respeitam seus limites.',
        nextId: 'final_positivo_festa',
        xpGain: 40,
        feedback: 'Parabéns! É totalmente possível se divertir com responsabilidade e alegria.'
      },
      {
        text: 'Convidar a turma para ir ao Parque do Lago Francisco Rizzo no sábado jogar basquete.',
        nextId: 'final_esporte',
        xpGain: 50,
        feedback: 'Fantástico! Incentivar hábitos saudáveis em grupo fortalece laços reais.'
      }
    ]
  },
  aceita_pressao: {
    id: 'aceita_pressao',
    character: 'Lucas, 15 anos',
    title: 'As Consequências no Dia Seguinte',
    situation: 'Lucas usa o vape e consome bebida alcoólica. Horas depois, sente tontura forte, enjoo e precisa ir embora cedo, passando mal. No dia seguinte, acorda com dor de cabeça e preocupado com a reação de seus pais, percebendo que a experiência não valeu a pena.',
    choices: [
      {
        text: 'Conversar abertamente com seus pais, admitir o erro e pedir orientação.',
        nextId: 'conversa_pais',
        xpGain: 35,
        feedback: 'Atitude madura! Ter coragem para pedir apoio em casa reforça a confiança na família.'
      },
      {
        text: 'Tentar esconder tudo e isolar-se no quarto durante o fim de semana.',
        nextId: 'final_isolamento',
        xpGain: 10,
        feedback: 'Esconder problemas e se isolar aumenta a ansiedade e o peso da culpa.'
      }
    ]
  },
  muda_foco: {
    id: 'muda_foco',
    character: 'Lucas, 15 anos',
    title: 'Criando Bons Momentos',
    situation: 'A turma vai jogar partidas de futebol de mesa e videogame. A festa fica super animada sem a necessidade de nenhuma substância tóxica. No final da noite, Lucas volta para casa satisfeito e com a consciência leve.',
    choices: [
      {
        text: 'Comentar com a família no café da manhã sobre o quanto o projeto de esportes tem sido legal.',
        nextId: 'final_esporte',
        xpGain: 40,
        feedback: 'Incrível! O apoio da família e dos esportes é um grande protetor.'
      }
    ]
  },
  conversa_pais: {
    id: 'conversa_pais',
    character: 'Lucas e sua Família',
    title: 'Acolhimento e Novo Começo',
    situation: 'Os pais de Lucas escutam com calma. Embora chateados com o risco que o filho correu, eles valorizam a sinceridade de Lucas. Juntos, alinham novas combinações, e o pai convida Lucas para participar de uma oficina cultural no centro de Embu das Artes.',
    choices: [
      {
        text: 'Inscrever-se no projeto de esporte/música comunitário e focar no futuro.',
        nextId: 'final_superacao',
        xpGain: 45,
        feedback: 'Muito bem! Erros podem se transformar em aprendizados valiosos com diálogo.'
      }
    ]
  },
  final_positivo_festa: {
    id: 'final_positivo_festa',
    character: 'Conquista de Lucas',
    title: 'Final: Campeão da Autonomia!',
    situation: 'Lucas provou que a verdadeira liderança é ter coragem para ser autêntico. Ele se divertiu muito, fez novas amizades sinceras e virou uma referência positiva na turma!',
    isEnding: true,
    endingMessage: 'Você concluiu a história com sucesso! Fazer escolhas conscientes protege sua vida e inspira as pessoas ao seu redor.',
    endingType: 'positive',
    choices: []
  },
  final_esporte: {
    id: 'final_esporte',
    character: 'Conquista de Lucas',
    title: 'Final: Vida Saudável e Amizades Reais',
    situation: 'O fim de semana de Lucas foi repleto de esporte, risadas ao ar livre no Parque Rizzo e conexão com a família. Ele descobriu que a verdadeira dopamina vem de momentos autênticos.',
    isEnding: true,
    endingMessage: 'Parabéns! Escolher hábitos saudáveis e estar perto de quem te ama é o melhor caminho!',
    endingType: 'positive',
    choices: []
  },
  final_superacao: {
    id: 'final_superacao',
    character: 'Conquista de Lucas',
    title: 'Final: Força do Diálogo Familiar',
    situation: 'Lucas fortaleceu o laço com seus pais e aprendeu a lidar com a pressão social. Agora, quando surge uma situação difícil, ele sabe que sempre pode contar com sua família e com orientações do GEPAD.',
    isEnding: true,
    endingMessage: 'Excelente! Pedir ajuda e valorizar a família faz toda a diferença.',
    endingType: 'positive',
    choices: []
  },
  final_isolamento: {
    id: 'final_isolamento',
    character: 'Reflexão de Lucas',
    title: 'Final: Momento de Aprender com o Erro',
    situation: 'Lucas percebeu que guardar o problema para si só gerou mais ansiedade. No entanto, o mascote GÊ lembra a Lucas que nunca é tarde para conversar com alguém de confiança ou ligar para os canais de apoio.',
    isEnding: true,
    endingMessage: 'Lembre-se: você nunca está sozinho! Sempre há alguém pronto para ouvir e apoiar na família, escola e na rede de apoio de Embu das Artes.',
    endingType: 'lesson',
    choices: []
  }
};
