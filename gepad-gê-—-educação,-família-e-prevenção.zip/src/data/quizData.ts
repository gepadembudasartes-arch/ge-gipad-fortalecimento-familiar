import { QuizQuestion } from '../types';

export const QUIZ_QUESTIONS: QuizQuestion[] = [
  {
    id: 1,
    statement: 'O cigarro eletrônico (vape/pod) é inofensivo porque solta apenas vapor com sabor de frutas.',
    isTrue: false,
    category: 'Substâncias e Saúde',
    explanation: 'MITO! Os cigarros eletrônicos contêm nicotina em altíssima concentração, além de solventes, metais pesados e compostos químicos que causam rápida dependência e sérias lesões pulmonares.'
  },
  {
    id: 2,
    statement: 'Ter um diálogo aberto e amoroso dentro de casa ajuda a prevenir comportamentos de risco entre os jovens.',
    isTrue: true,
    category: 'Família e Relações',
    explanation: 'VERDADE! Famílias com boa comunicação, afeto e presença atenta criam um ambiente protetor fundamental para que jovens desenvolvam autoconfiança e resiliência.'
  },
  {
    id: 3,
    statement: 'Mudar repentinamente de amigos, perder o interesse pela escola e isolar-se podem ser sinais de que alguém precisa de ajuda.',
    isTrue: true,
    category: 'Sinais de Alerta',
    explanation: 'VERDADE! Alterações bruscas e duradouras de comportamento merecem olhar atento dos pais e professores para oferecer apoio precoce.'
  },
  {
    id: 4,
    statement: 'Dizer "não" a convites para experimentar álcool ou drogas faz a pessoa perder amigos de verdade.',
    isTrue: false,
    category: 'Escolhas e Amizades',
    explanation: 'MITO! Amigos de verdade respeitam seus limites e suas escolhas de vida. Quem força você a fazer algo nocivo não está preocupado com o seu bem-estar.'
  },
  {
    id: 5,
    statement: 'A prática constante de esportes, artes e hobbies ajuda na liberação natural de dopamina e bem-estar emocional.',
    isTrue: true,
    category: 'Hábitos Saudáveis',
    explanation: 'VERDADE! Atividades físicas, música, esportes e hobbies ativam o sistema de recompensa do cérebro de forma natural e saudável, combatendo o estresse e a ansiedade.'
  },
  {
    id: 6,
    statement: 'Misturar bebidas energéticas com álcool reduz os perigos do consumo.',
    isTrue: false,
    category: 'Mitos de Saúde',
    explanation: 'MITO! Os estimulantes das bebidas energéticas mascaram a sensação de embriaguez, fazendo a pessoa consumir mais álcool sem perceber, aumentando riscos de coma alcoólico e arritmias cardíacas.'
  },
  {
    id: 7,
    statement: 'O GEPAD da Guarda Civil Municipal de Embu das Artes atua com palestras preventivas e ações educativas nas escolas.',
    isTrue: true,
    category: 'Cidadania e GEPAD',
    explanation: 'VERDADE! O GEPAD atua preventivamente aproximando a segurança pública das escolas e famílias para promover cidadania, proteção e respeito à vida.'
  },
  {
    id: 8,
    statement: 'Buscar ajuda em CAPS, Conselho Tutelar ou no CVV (188) é sinal de fraqueza.',
    isTrue: false,
    category: 'Rede de Apoio',
    explanation: 'MITO! Reconhecer quando se precisa de apoio profissional é um ato de coragem e amor próprio. A rede pública de apoio oferece acolhimento gratuito e sigiloso.'
  }
];
