import React, { useState, useEffect } from 'react';
import { Header } from './components/Header';
import { HomeSection } from './components/HomeSection';
import { ChatSection } from './components/ChatSection';
import { GuidesSection } from './components/GuidesSection';
import { GamesSection } from './components/GamesSection';
import { CommunitySection } from './components/CommunitySection';
import { SupportSection } from './components/SupportSection';
import { ProfileSection } from './components/ProfileSection';
import { GepadLogo } from './components/GepadLogo';
import { ActiveTab, UserRole } from './types';
import { ShieldCheck, Heart, PhoneCall, Sparkles } from 'lucide-react';

export default function App() {
  const [activeTab, setActiveTab] = useState<ActiveTab>('home');
  const [userRole, setUserRole] = useState<UserRole>('estudante');
  const [userName, setUserName] = useState<string>('Visitante');
  const [schoolOrNeighborhood, setSchoolOrNeighborhood] = useState<string>('Embu das Artes');

  const [xp, setXp] = useState<number>(20);
  const [completedQuizzes, setCompletedQuizzes] = useState<number>(0);
  const [readGuides, setReadGuides] = useState<string[]>([]);

  // Calculate Level dynamically from XP
  const level = Math.floor(xp / 50) + 1;

  const rewardXp = (amount: number) => {
    setXp((prev) => prev + amount);
  };

  const markGuideAsRead = (guideId: string) => {
    if (!readGuides.includes(guideId)) {
      setReadGuides((prev) => [...prev, guideId]);
      rewardXp(20);
    }
  };

  const incrementQuizCount = () => {
    setCompletedQuizzes((prev) => prev + 1);
  };

  return (
    <div className="min-h-screen bg-[#08090E] text-slate-100 bg-cyber-grid flex flex-col font-sans selection:bg-purple-600 selection:text-white">
      {/* Header Bar */}
      <Header
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        xp={xp}
        level={level}
        userRole={userRole}
        setUserRole={setUserRole}
        userName={userName}
      />

      {/* Main Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6 sm:py-8">
        {activeTab === 'home' && (
          <HomeSection
            setActiveTab={setActiveTab}
            userRole={userRole}
            userName={userName}
            xp={xp}
          />
        )}

        {activeTab === 'chat' && (
          <ChatSection
            userRole={userRole}
            userName={userName}
            onRewardXp={rewardXp}
            setActiveTab={setActiveTab}
          />
        )}

        {activeTab === 'guides' && (
          <GuidesSection
            userRole={userRole}
            readGuides={readGuides}
            onMarkAsRead={markGuideAsRead}
          />
        )}

        {activeTab === 'games' && (
          <GamesSection
            onRewardXp={rewardXp}
            onIncrementQuizCount={incrementQuizCount}
          />
        )}

        {activeTab === 'community' && (
          <CommunitySection
            userRole={userRole}
            userName={userName}
            onRewardXp={rewardXp}
          />
        )}

        {activeTab === 'support' && <SupportSection />}

        {activeTab === 'profile' && (
          <ProfileSection
            userName={userName}
            setUserName={setUserName}
            userRole={userRole}
            setUserRole={setUserRole}
            schoolOrNeighborhood={schoolOrNeighborhood}
            setSchoolOrNeighborhood={setSchoolOrNeighborhood}
            xp={xp}
            level={level}
            completedQuizzes={completedQuizzes}
            readGuidesCount={readGuides.length}
          />
        )}
      </main>

      {/* Footer in Gothic Cyber Theme */}
      <footer className="bg-[#05060A] text-slate-400 py-8 px-4 border-t border-purple-900/40 mt-auto">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-6 text-xs text-center md:text-left">
          <div className="flex items-center gap-3">
            <GepadLogo size={38} variant="compact" glow={true} />
            <div className="space-y-0.5">
              <div className="flex items-center justify-center md:justify-start gap-2 text-cyan-300 font-cyber font-bold text-sm">
                <span>GÊ • PLATAFORMA GÓTICO-FUTURISTA GEPAD</span>
              </div>
              <p className="text-slate-500 font-mono text-[11px]">
                Guarda Civil Municipal de Embu das Artes • Estado de São Paulo
              </p>
            </div>
          </div>

          <div className="flex flex-wrap justify-center gap-4 text-slate-400 font-cyber font-medium text-xs">
            <button
              onClick={() => setActiveTab('support')}
              className="hover:text-rose-300 flex items-center gap-1.5 text-rose-400 font-bold cursor-pointer"
            >
              <PhoneCall className="w-3.5 h-3.5" />
              EMERGÊNCIA GCM: 153
            </button>
            <span className="text-purple-900">•</span>
            <button onClick={() => setActiveTab('guides')} className="hover:text-cyan-300 cursor-pointer">
              Codex Prevenção
            </button>
            <span className="text-purple-900">•</span>
            <button onClick={() => setActiveTab('games')} className="hover:text-cyan-300 cursor-pointer">
              Desafios & Quiz
            </button>
          </div>

          <p className="text-slate-600 font-mono text-[11px]">
            © {new Date().getFullYear()} GEPAD GCM Embu das Artes.
          </p>
        </div>
      </footer>
    </div>
  );
}
